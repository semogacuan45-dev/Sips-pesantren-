# SIPS — Sistem Informasi Pesantren Santri

Aplikasi manajemen pesantren tahfidz berbasis Progressive Web App (PWA): data santri, hafalan, tahsin, absensi, keuangan/uang jajan, pelanggaran, prestasi, laporan, dan panel admin. Dibangun dengan React + Vite + Tailwind CSS + Firebase, siap di-hosting di Netlify dan diinstal di Android sebagai aplikasi (tanpa Play Store).

## 0. Dua Mode Data: Lokal vs Cloud

Aplikasi ini punya **dua mode penyimpanan data** yang bisa dipilih langsung dari halaman Login:

| | **Mode Lokal** | **Mode Cloud** |
|---|---|---|
| Setup awal | Tidak perlu apapun, langsung jalan | Perlu setup proyek Firebase (lihat bagian 3) |
| Tempat data disimpan | Browser HP/PC masing-masing (localStorage) | Firebase (server Google) |
| Sinkron antar HP/pengguna | ❌ Tidak — data Admin, Musyrif, Wali **terpisah** per perangkat | ✅ Ya — semua pengguna melihat data yang sama secara real-time |
| Keamanan akun | Sangat minim (password tersimpan polos di browser) — **hanya untuk uji coba** | Aman, memakai Firebase Authentication |
| Kapan dipakai | Coba-coba fitur, demo ke pengurus pesantren, latihan sebelum setup Firebase | Pemakaian sungguhan sehari-hari di pesantren |
| Akun siap pakai | 4 akun demo otomatis (lihat bawah) | Anda buat sendiri lewat panel Admin |

**Akun demo Mode Lokal** (muncul juga sebagai tombol pintas di halaman Login):
- Admin: `admin@demo.sips` / `admin123`
- Bendahara: `bendahara@demo.sips` / `bendahara123`
- Musyrif/Ustadz: `musyrif@demo.sips` / `musyrif123`
- Wali Santri: `wali@demo.sips` / `wali123`

**Penting:** Mode Lokal cocok untuk *mencoba aplikasinya seperti apa* tanpa setup apapun — cukup buka situs Netlify-nya, pilih "Mode Lokal", login pakai akun demo. Tapi karena datanya hanya tersimpan di satu browser (tidak sinkron), **untuk pemakaian sungguhan oleh banyak pengguna (Admin, Musyrif, Wali Santri) di perangkat berbeda, wajib pakai Mode Cloud** dengan Firebase. Anda bisa berpindah mode kapan saja lewat halaman Login atau menu Admin → "Mode & Data".

## 0.5 Troubleshooting: "Page not found" di Netlify

Ini biasanya terjadi karena salah satu dari dua hal berikut:

**A. Anda drag-and-drop folder/zip project mentah (belum di-build).**
Netlify punya dua cara deploy yang sangat berbeda:
- **Manual drag & drop** (area "Deploy manually" di dashboard Netlify): Netlify **TIDAK menjalankan build apapun** — ia hanya menyajikan persis file yang Anda taruh di sana. Kalau yang di-drop adalah folder project mentah (berisi `src/`, `package.json`, dll — bukan hasil build), maka **wajib** jalankan `npm install && npm run build` dulu di komputer Anda, lalu **drag folder `dist/` yang dihasilkan** (bukan folder project-nya) ke Netlify.
- **Import dari Git** (GitHub/GitLab terhubung ke Netlify): Netlify otomatis menjalankan `npm run build` sesuai `netlify.toml`. Ini cara yang direkomendasikan karena tidak perlu build manual tiap kali ada perubahan.

**B. Struktur folder tidak sesuai (ada folder pembungkus tambahan).**
Pastikan `index.html`, `package.json`, `netlify.toml` berada tepat di **root** repo/folder yang dihubungkan ke Netlify — bukan di dalam satu folder pembungkus lagi (misal `project/sips/index.html`). Kalau repo Anda punya folder pembungkus, set **Base directory** di Netlify Site settings → Build & deploy sesuai nama folder tersebut.

Sebagai pengaman tambahan, proyek ini sudah menyertakan file `public/_redirects` (disalin otomatis ke `dist/` saat build) sebagai cadangan untuk `netlify.toml`, supaya SPA routing tetap bekerja meski salah satu konfigurasi terlewat.

## 1. Fitur Utama

- **4 Role pengguna**: Admin, Bendahara, Musyrif/Ustadz, Wali Santri — masing-masing punya dashboard & hak akses berbeda.
- **Data Santri**: CRUD lengkap, foto, QR Code, pencarian, filter, import/export Excel.
- **Tahfidz**: input harian (surat, ayat, ziyadah, murajaah, nilai, kelancaran, tajwid), grafik perkembangan.
- **Tahsin**: penilaian makhraj, sifat huruf, mad, ghunnah, kelancaran.
- **Absensi**: hadir/izin/sakit/alpa/terlambat per kelas per hari.
- **Uang Jajan**: dompet digital per santri (top up, tarik, jajan, transfer) dengan transaksi atomik.
- **Pelanggaran & Prestasi**: dengan foto bukti/sertifikat.
- **Laporan**: harian/mingguan/bulanan/semester/tahunan, export PDF/Excel/Print.
- **Panel Admin**: kelola guru & akun, kelas, kamar, backup & restore database, reset kata sandi.
- **PWA**: bisa diinstal di Android, offline cache, dark mode, mobile-first.

### Integrasi Premium: Sistem Informasi ⇄ Uang Jajan

- **Denda otomatis**: saat mencatat Pelanggaran, isi kolom "Denda" → saldo Uang Jajan santri otomatis terpotong dan tercatat di riwayat Transaksi (dengan penanganan bila saldo tidak cukup).
- **Hadiah otomatis**: saat mencatat Prestasi, isi kolom "Hadiah" → saldo Uang Jajan santri otomatis bertambah sebagai apresiasi.
- **Kasir Jajan (scan QR)**: halaman khusus Admin/Bendahara untuk transaksi jajan/top up super cepat — scan QR santri pakai kamera HP (atau cari manual via NIS), pilih nominal, konfirmasi. Cocok dipakai di kantin/koperasi pesantren.
- **Detail Santri 360°**: klik nama santri di Data Santri untuk melihat satu halaman lengkap — profil, rata-rata nilai hafalan, tingkat kehadiran, saldo jajan, total denda, total hadiah, riwayat hafalan, dan riwayat pelanggaran/prestasi sekaligus.
- **Indikator saldo menipis**: badge otomatis muncul di halaman Uang Jajan untuk santri dengan saldo di bawah Rp10.000, membantu Bendahara mengingatkan Wali untuk top up.

## 2. Prasyarat

- Node.js 18+ dan npm
- Akun Firebase (gratis) — https://console.firebase.google.com

## 3. Setup Firebase

1. Buat proyek baru di [Firebase Console](https://console.firebase.google.com).
2. Aktifkan **Authentication** → sign-in method **Email/Password**.
3. Aktifkan **Firestore Database** (mode production).
4. Aktifkan **Storage**.
5. Buka **Project Settings → General → Your apps → Web app**, salin konfigurasi (`apiKey`, `authDomain`, dst).

> ⚠️ **Catatan tentang Storage**: sejak Februari 2026, Google mewajibkan proyek Firebase menghubungkan kartu kredit/debit (upgrade ke paket Blaze) hanya untuk *mengaktifkan* Cloud Storage — meskipun pemakaian Anda tetap Rp0 selama di bawah kuota gratis (5 GB penyimpanan/bulan, jauh cukup untuk foto santri skala 150-500 orang). Kalau Anda tidak ingin memasukkan kartu sama sekali, lewati langkah "Aktifkan Storage" di bawah — aplikasi tetap berjalan normal, hanya fitur upload foto (foto santri, bukti pelanggaran, sertifikat prestasi) yang tidak berfungsi di Mode Cloud.
6. Salin `.env.example` menjadi `.env`, lalu isi dengan konfigurasi tersebut:

   ```bash
   cp .env.example .env
   ```

7. Deploy aturan keamanan (opsional tapi sangat disarankan) menggunakan Firebase CLI:

   ```bash
   npm install -g firebase-tools
   firebase login
   firebase init firestore storage   # pilih proyek yang sudah dibuat, gunakan file rules yang sudah ada
   firebase deploy --only firestore:rules,storage:rules
   ```

8. Buat **akun Admin pertama** secara manual (karena panel Admin butuh login admin lebih dulu):
   - Di Firebase Console → Authentication → Add user (masukkan email & password).
   - Di Firestore → buat koleksi `users` → tambah dokumen dengan field:
     ```
     uid: <UID dari user yang baru dibuat>
     email: <email tadi>
     name: "Admin Pesantren"
     role: "admin"
     ```

## 4. Instalasi & Menjalankan Secara Lokal

```bash
npm install
npm run dev
```

Buka `http://localhost:5173`, login menggunakan akun admin yang sudah dibuat di langkah 3.8.

## 5. Build Production

```bash
npm run build
npm run preview   # untuk mencoba hasil build secara lokal
```

## 6. Deploy ke Netlify

**Opsi A — via Netlify CLI:**
```bash
npm install -g netlify-cli
netlify deploy --prod
```

**Opsi B — via Git:**
1. Push folder ini ke repository GitHub/GitLab.
2. Di Netlify → "Add new site" → "Import an existing project" → hubungkan repo.
3. Build command: `npm run build`, Publish directory: `dist` (sudah diatur otomatis di `netlify.toml`).
4. Tambahkan environment variables (`VITE_FIREBASE_*`) di Netlify → Site settings → Environment variables, sesuai isi `.env` Anda.
5. Deploy.

## 7. Instal sebagai Aplikasi Android (PWA)

1. Buka URL Netlify Anda di Chrome Android.
2. Ketuk menu (⋮) → **"Add to Home screen" / "Install app"**.
3. Aplikasi akan terpasang seperti aplikasi native, lengkap dengan ikon & splash screen, tanpa perlu Play Store.

## 8. Struktur Folder

```
sips/
├── public/
│   └── icons/              # Ikon PWA (192, 512, maskable, apple-touch, favicon)
├── src/
│   ├── components/         # Komponen UI (Sidebar, BottomNav, modal form, dll)
│   ├── context/            # AuthContext, ThemeContext
│   ├── firebase/           # Konfigurasi Firebase
│   ├── hooks/               # Custom hooks (useFirestoreCollection, useDashboardStats)
│   ├── pages/               # Halaman per modul (Dashboard, Students, Tahfidz, dst)
│   ├── routes/               # ProtectedRoute
│   ├── services/            # Logic akses Firestore per modul
│   └── utils/                # Format angka/tanggal, konfigurasi navigasi
├── firestore.rules          # Aturan keamanan Firestore (role-based)
├── storage.rules             # Aturan keamanan Storage
├── netlify.toml               # Konfigurasi build & redirect Netlify
└── vite.config.js             # Konfigurasi Vite + plugin PWA
```

## 9. Struktur Koleksi Firestore

| Koleksi | Keterangan |
|---|---|
| `users` | Profil pengguna & role |
| `students` | Data santri |
| `classes`, `rooms` | Master data kelas & kamar |
| `attendance` | Absensi harian |
| `tahfidz`, `tahsin` | Catatan hafalan & penilaian tahsin |
| `violations` | Pelanggaran santri |
| `achievements` | Prestasi santri |
| `wallets` | Saldo dompet digital per santri |
| `transactions` | Riwayat transaksi keuangan |
| `notifications` | Notifikasi sistem |
| `settings` | Pengaturan umum aplikasi |

## 10. Menambahkan Akun Wali Santri

Login sebagai Admin → menu **Admin → Guru & Akun** → buat akun baru dengan role **Wali Santri**, lalu hubungkan dengan data santri yang sesuai. Wali Santri hanya bisa **melihat** data (hafalan, absensi, nilai, saldo, riwayat jajan, prestasi, pelanggaran) — tidak bisa mengubah data.

## 11. Arsitektur Lapisan Data (untuk pengembang)

Semua halaman/komponen tidak memanggil Firestore secara langsung — mereka memanggil fungsi di `src/services/*.js`, yang kemudian memanggil `src/data/store.js` (facade). Facade inilah yang memutuskan menyimpan ke `localStorage` (`src/data/localStore.js`) atau ke Firestore, tergantung mode aktif (`src/data/mode.js`). Kalau ingin menambah modul/koleksi baru, cukup pakai fungsi `addRecord`, `updateRecord`, `deleteRecord`, `getAllOnce`, `subscribeCollection` dari `store.js` — otomatis mendukung kedua mode tanpa kode tambahan.

## 12. Catatan Pengembangan Lanjutan

Fondasi ini mencakup seluruh modul inti dan siap produksi. Beberapa penyempurnaan opsional yang bisa ditambahkan sesuai kebutuhan lapangan:
- Scan QR untuk absensi/transaksi jajan menggunakan kamera (library `html5-qrcode` sudah termasuk di `package.json`, tinggal diintegrasikan ke halaman Absensi/Keuangan).
- Verifikasi PIN santri sebelum transaksi jajan (field `pin` sudah tersedia di dokumen `wallets`).
- Push notification (Firebase Cloud Messaging) untuk notifikasi real-time ke HP Wali Santri.
- Target hafalan mingguan/bulanan otomatis dengan progress bar di halaman Tahfidz.

## 13. Lisensi & Dukungan

Proyek ini dibuat khusus untuk kebutuhan internal pesantren. Sesuaikan kembali data dummy/contoh sebelum digunakan pada data santri sungguhan.
