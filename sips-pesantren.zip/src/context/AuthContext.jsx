import { createContext, useContext, useEffect, useState } from 'react';
import {
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signOut as fbSignOut,
  sendPasswordResetEmail
} from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { auth, db } from '../firebase/config';
import { useDataMode } from './DataModeContext.jsx';
import { getAll, updateDoc as localUpdateDoc } from '../data/localStore';

const AuthContext = createContext(null);

export const ROLES = {
  ADMIN: 'admin',
  BENDAHARA: 'bendahara',
  MUSYRIF: 'musyrif',
  WALI: 'wali'
};

const LOCAL_SESSION_KEY = 'sips_local_session';

export function AuthProvider({ children }) {
  const { mode } = useDataMode();
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null); // { id, role, name, ... }
  const [loading, setLoading] = useState(true);

  // --- Mode Lokal: sesi disimpan di localStorage, tanpa Firebase Auth ---
  useEffect(() => {
    if (mode !== 'local') return;
    setLoading(true);
    const savedId = localStorage.getItem(LOCAL_SESSION_KEY);
    if (savedId) {
      const found = getAll('users').find((u) => u.id === savedId);
      if (found) {
        setUser({ uid: found.id, email: found.email });
        setProfile(found);
      } else {
        localStorage.removeItem(LOCAL_SESSION_KEY);
        setUser(null);
        setProfile(null);
      }
    } else {
      setUser(null);
      setProfile(null);
    }
    setLoading(false);
  }, [mode]);

  // --- Mode Cloud: memakai Firebase Authentication ---
  useEffect(() => {
    if (mode !== 'cloud') return;
    setLoading(true);
    const unsub = onAuthStateChanged(auth, async (fbUser) => {
      setLoading(true);
      if (fbUser) {
        setUser(fbUser);
        try {
          const snap = await getDoc(doc(db, 'users', fbUser.uid));
          setProfile(snap.exists() ? { id: snap.id, ...snap.data() } : null);
        } catch (e) {
          console.error('Gagal memuat profil pengguna:', e);
          setProfile(null);
        }
      } else {
        setUser(null);
        setProfile(null);
      }
      setLoading(false);
    });
    return unsub;
  }, [mode]);

  const login = async (email, password) => {
    if (mode === 'local') {
      const found = getAll('users').find((u) => u.email.toLowerCase() === email.toLowerCase() && u.password === password);
      if (!found) {
        const err = new Error('Email atau kata sandi salah');
        err.code = 'auth/invalid-credential';
        throw err;
      }
      localStorage.setItem(LOCAL_SESSION_KEY, found.id);
      setUser({ uid: found.id, email: found.email });
      setProfile(found);
      return found;
    }
    return signInWithEmailAndPassword(auth, email, password);
  };

  const logout = async () => {
    if (mode === 'local') {
      localStorage.removeItem(LOCAL_SESSION_KEY);
      setUser(null);
      setProfile(null);
      return;
    }
    return fbSignOut(auth);
  };

  const resetPassword = async (email) => {
    if (mode === 'local') {
      const users = getAll('users');
      const found = users.find((u) => u.email.toLowerCase() === email.toLowerCase());
      if (!found) {
        const err = new Error('Email tidak ditemukan');
        err.code = 'auth/user-not-found';
        throw err;
      }
      const tempPassword = 'sips12345';
      localUpdateDoc('users', found.id, { password: tempPassword });
      return { localReset: true, tempPassword };
    }
    return sendPasswordResetEmail(auth, email);
  };

  const value = {
    user,
    profile,
    role: profile?.role || null,
    loading,
    mode,
    login,
    logout,
    resetPassword,
    isAdmin: profile?.role === ROLES.ADMIN,
    isBendahara: profile?.role === ROLES.BENDAHARA,
    isMusyrif: profile?.role === ROLES.MUSYRIF,
    isWali: profile?.role === ROLES.WALI
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export const useAuth = () => useContext(AuthContext);
