import { createContext, useContext, useEffect, useState } from 'react';
import { getMode, setMode, onModeChange, isCloudConfigured } from '../data/mode';
import { seedDemoData } from '../data/localStore';

const DataModeContext = createContext(null);

export function DataModeProvider({ children }) {
  const [mode, setModeState] = useState(getMode());

  useEffect(() => onModeChange(setModeState), []);

  useEffect(() => {
    if (mode === 'local') seedDemoData();
  }, [mode]);

  const switchMode = (m) => setMode(m);

  return (
    <DataModeContext.Provider value={{ mode, switchMode, cloudConfigured: isCloudConfigured() }}>
      {children}
    </DataModeContext.Provider>
  );
}

export const useDataMode = () => useContext(DataModeContext);
