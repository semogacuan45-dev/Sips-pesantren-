export function formatRupiah(value = 0) {
  return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(value || 0);
}

export function formatTanggal(date, opts = {}) {
  if (!date) return '-';
  const d = date?.toDate ? date.toDate() : new Date(date);
  return new Intl.DateTimeFormat('id-ID', { day: '2-digit', month: 'long', year: 'numeric', ...opts }).format(d);
}

export function formatTanggalSingkat(date) {
  if (!date) return '-';
  const d = date?.toDate ? date.toDate() : new Date(date);
  return new Intl.DateTimeFormat('id-ID', { day: '2-digit', month: '2-digit', year: 'numeric' }).format(d);
}
