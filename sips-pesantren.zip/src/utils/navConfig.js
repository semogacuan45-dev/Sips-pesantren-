import {
  LayoutDashboard, Users, BookOpen, CalendarCheck, Wallet,
  AlertTriangle, Award, Receipt, FileText, Settings, GraduationCap, ScanLine
} from 'lucide-react';
import { ROLES } from '../context/AuthContext.jsx';

// Menu utama yang tampil di Sidebar (desktop) & sebagian di Bottom Nav (mobile)
export const NAV_ITEMS = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard, roles: [ROLES.ADMIN, ROLES.BENDAHARA, ROLES.MUSYRIF, ROLES.WALI] },
  { to: '/santri', label: 'Data Santri', icon: Users, roles: [ROLES.ADMIN, ROLES.MUSYRIF] },
  { to: '/tahfidz', label: 'Tahfidz', icon: BookOpen, roles: [ROLES.ADMIN, ROLES.MUSYRIF, ROLES.WALI] },
  { to: '/tahsin', label: 'Tahsin', icon: GraduationCap, roles: [ROLES.ADMIN, ROLES.MUSYRIF, ROLES.WALI] },
  { to: '/absensi', label: 'Absensi', icon: CalendarCheck, roles: [ROLES.ADMIN, ROLES.MUSYRIF, ROLES.WALI] },
  { to: '/keuangan', label: 'Uang Jajan', icon: Wallet, roles: [ROLES.ADMIN, ROLES.BENDAHARA, ROLES.WALI] },
  { to: '/kasir', label: 'Kasir Jajan', icon: ScanLine, roles: [ROLES.ADMIN, ROLES.BENDAHARA] },
  { to: '/transaksi', label: 'Transaksi', icon: Receipt, roles: [ROLES.ADMIN, ROLES.BENDAHARA] },
  { to: '/pelanggaran', label: 'Pelanggaran', icon: AlertTriangle, roles: [ROLES.ADMIN, ROLES.MUSYRIF, ROLES.WALI] },
  { to: '/prestasi', label: 'Prestasi', icon: Award, roles: [ROLES.ADMIN, ROLES.MUSYRIF, ROLES.WALI] },
  { to: '/laporan', label: 'Laporan', icon: FileText, roles: [ROLES.ADMIN, ROLES.BENDAHARA, ROLES.MUSYRIF] },
  { to: '/admin', label: 'Admin', icon: Settings, roles: [ROLES.ADMIN] }
];

// 5 item prioritas untuk Bottom Navigation mobile (per role, agar tidak penuh)
export const BOTTOM_NAV_BY_ROLE = {
  [ROLES.ADMIN]: ['/', '/santri', '/kasir', '/keuangan', '/admin'],
  [ROLES.BENDAHARA]: ['/', '/kasir', '/keuangan', '/transaksi', '/laporan'],
  [ROLES.MUSYRIF]: ['/', '/santri', '/tahfidz', '/absensi', '/laporan'],
  [ROLES.WALI]: ['/', '/tahfidz', '/absensi', '/keuangan', '/prestasi']
};
