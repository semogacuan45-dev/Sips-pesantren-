import { Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import ProtectedRoute from './routes/ProtectedRoute.jsx';
import AppLayout from './components/AppLayout.jsx';
import Login from './pages/Login.jsx';
import Dashboard from './pages/Dashboard.jsx';
import Students from './pages/Students.jsx';
import StudentDetail from './pages/StudentDetail.jsx';
import Tahfidz from './pages/Tahfidz.jsx';
import Tahsin from './pages/Tahsin.jsx';
import Attendance from './pages/Attendance.jsx';
import WalletPage from './pages/Wallet.jsx';
import Transactions from './pages/Transactions.jsx';
import Kasir from './pages/Kasir.jsx';
import Violations from './pages/Violations.jsx';
import Achievements from './pages/Achievements.jsx';
import Reports from './pages/Reports.jsx';
import Notifications from './pages/Notifications.jsx';
import Admin from './pages/Admin.jsx';
import { ROLES } from './context/AuthContext.jsx';

export default function App() {
  return (
    <>
      <Toaster position="top-center" toastOptions={{ duration: 3000 }} />
      <Routes>
        <Route path="/login" element={<Login />} />

        <Route
          element={
            <ProtectedRoute>
              <AppLayout />
            </ProtectedRoute>
          }
        >
          <Route path="/" element={<Dashboard />} />
          <Route
            path="/santri"
            element={
              <ProtectedRoute allowedRoles={[ROLES.ADMIN, ROLES.MUSYRIF]}>
                <Students />
              </ProtectedRoute>
            }
          />
          <Route
            path="/santri/:id"
            element={
              <ProtectedRoute allowedRoles={[ROLES.ADMIN, ROLES.MUSYRIF]}>
                <StudentDetail />
              </ProtectedRoute>
            }
          />
          <Route path="/tahfidz" element={<Tahfidz />} />
          <Route path="/tahsin" element={<Tahsin />} />
          <Route path="/absensi" element={<Attendance />} />
          <Route
            path="/keuangan"
            element={
              <ProtectedRoute allowedRoles={[ROLES.ADMIN, ROLES.BENDAHARA, ROLES.WALI]}>
                <WalletPage />
              </ProtectedRoute>
            }
          />
          <Route
            path="/kasir"
            element={
              <ProtectedRoute allowedRoles={[ROLES.ADMIN, ROLES.BENDAHARA]}>
                <Kasir />
              </ProtectedRoute>
            }
          />
          <Route
            path="/transaksi"
            element={
              <ProtectedRoute allowedRoles={[ROLES.ADMIN, ROLES.BENDAHARA]}>
                <Transactions />
              </ProtectedRoute>
            }
          />
          <Route path="/pelanggaran" element={<Violations />} />
          <Route path="/prestasi" element={<Achievements />} />
          <Route
            path="/laporan"
            element={
              <ProtectedRoute allowedRoles={[ROLES.ADMIN, ROLES.BENDAHARA, ROLES.MUSYRIF]}>
                <Reports />
              </ProtectedRoute>
            }
          />
          <Route path="/notifikasi" element={<Notifications />} />
          <Route
            path="/admin"
            element={
              <ProtectedRoute allowedRoles={[ROLES.ADMIN]}>
                <Admin />
              </ProtectedRoute>
            }
          />
        </Route>
      </Routes>
    </>
  );
}
