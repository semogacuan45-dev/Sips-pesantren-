import { useMemo, useState } from 'react';
import { Search, ArrowDownLeft, ArrowUpRight, RefreshCcw, Undo2 } from 'lucide-react';
import { useFirestoreCollection } from '../hooks/useFirestoreCollection';
import { TableRowSkeleton } from '../components/Skeleton.jsx';
import { formatRupiah, formatTanggalSingkat } from '../utils/format.js';

const TYPE_META = {
  masuk: { label: 'Masuk', icon: ArrowDownLeft, color: 'text-green-600 bg-green-50 dark:bg-green-900/20' },
  keluar: { label: 'Keluar', icon: ArrowUpRight, color: 'text-red-600 bg-red-50 dark:bg-red-900/20' },
  jajan: { label: 'Jajan', icon: ArrowUpRight, color: 'text-amber-600 bg-amber-50 dark:bg-amber-900/20' },
  transfer: { label: 'Transfer', icon: RefreshCcw, color: 'text-blue-600 bg-blue-50 dark:bg-blue-900/20' },
  refund: { label: 'Refund', icon: Undo2, color: 'text-purple-600 bg-purple-50 dark:bg-purple-900/20' }
};

export default function Transactions() {
  const { data: transactions, loading } = useFirestoreCollection('transactions', 'createdAt', 'desc');
  const [search, setSearch] = useState('');
  const [jenisFilter, setJenisFilter] = useState('');

  const filtered = useMemo(() => {
    return transactions.filter((t) => {
      const matchSearch = !search || t.studentName?.toLowerCase().includes(search.toLowerCase());
      const matchJenis = !jenisFilter || t.jenis === jenisFilter;
      return matchSearch && matchJenis;
    });
  }, [transactions, search, jenisFilter]);

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-xl font-bold text-gray-900 dark:text-white">Riwayat Transaksi</h2>
        <p className="text-sm text-gray-500 dark:text-gray-400">{filtered.length} transaksi tercatat</p>
      </div>

      <div className="flex flex-col md:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Cari nama santri..." className="input-field pl-9" />
        </div>
        <select className="input-field md:w-48" value={jenisFilter} onChange={(e) => setJenisFilter(e.target.value)}>
          <option value="">Semua Jenis</option>
          {Object.entries(TYPE_META).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
        </select>
      </div>

      <div className="card !p-0 overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-gray-400 border-b border-gray-100 dark:border-gray-700">
              <th className="py-3 px-4 font-medium">Tanggal</th>
              <th className="py-3 px-4 font-medium">Santri</th>
              <th className="py-3 px-4 font-medium">Jenis</th>
              <th className="py-3 px-4 font-medium text-right">Nominal</th>
              <th className="py-3 px-4 font-medium">Catatan</th>
            </tr>
          </thead>
          <tbody>
            {loading && Array.from({ length: 6 }).map((_, i) => <TableRowSkeleton key={i} cols={5} />)}
            {!loading && filtered.length === 0 && (
              <tr><td colSpan={5} className="text-center py-10 text-gray-400">Belum ada transaksi.</td></tr>
            )}
            {!loading && filtered.slice(0, 100).map((t) => {
              const meta = TYPE_META[t.jenis] || TYPE_META.masuk;
              const Icon = meta.icon;
              return (
                <tr key={t.id} className="border-b border-gray-50 dark:border-gray-700/50">
                  <td className="py-2.5 px-4 text-gray-500 dark:text-gray-400 whitespace-nowrap">{formatTanggalSingkat(t.createdAt)}</td>
                  <td className="py-2.5 px-4 font-medium text-gray-900 dark:text-white">{t.studentName}</td>
                  <td className="py-2.5 px-4">
                    <span className={`inline-flex items-center gap-1 text-xs px-2 py-1 rounded-full font-medium ${meta.color}`}>
                      <Icon size={12} /> {meta.label}
                    </span>
                  </td>
                  <td className="py-2.5 px-4 text-right font-semibold text-gray-900 dark:text-white">{formatRupiah(t.nominal)}</td>
                  <td className="py-2.5 px-4 text-gray-400 truncate max-w-[200px]">{t.catatan || '-'}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
