import { useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Plus, Upload, Download, QrCode, Pencil, Trash2, ChevronLeft, ChevronRight, ExternalLink } from 'lucide-react';
import toast from 'react-hot-toast';
import QRCode from 'qrcode.react';
import { useFirestoreCollection } from '../hooks/useFirestoreCollection';
import { deleteStudent, exportStudentsToExcel, importStudentsFromExcel } from '../services/studentService';
import StudentFormModal from '../components/StudentFormModal.jsx';
import ConfirmDialog from '../components/ConfirmDialog.jsx';
import { TableRowSkeleton } from '../components/Skeleton.jsx';
import { useAuth } from '../context/AuthContext.jsx';

const PAGE_SIZE = 10;

export default function Students() {
  const navigate = useNavigate();
  const { isAdmin, isMusyrif } = useAuth();
  const canEdit = isAdmin || isMusyrif;
  const { data: students, loading } = useFirestoreCollection('students', 'nama', 'asc');
  const fileInputRef = useRef(null);

  const [search, setSearch] = useState('');
  const [kelasFilter, setKelasFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [page, setPage] = useState(1);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [qrStudent, setQrStudent] = useState(null);
  const [toDelete, setToDelete] = useState(null);
  const [importing, setImporting] = useState(false);

  const kelasOptions = useMemo(() => [...new Set(students.map((s) => s.kelas).filter(Boolean))].sort(), [students]);

  const filtered = useMemo(() => {
    return students.filter((s) => {
      const matchSearch =
        !search ||
        s.nama?.toLowerCase().includes(search.toLowerCase()) ||
        s.nis?.toLowerCase().includes(search.toLowerCase());
      const matchKelas = !kelasFilter || s.kelas === kelasFilter;
      const matchStatus = !statusFilter || s.status === statusFilter;
      return matchSearch && matchKelas && matchStatus;
    });
  }, [students, search, kelasFilter, statusFilter]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const paginated = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  const handleImport = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setImporting(true);
    try {
      const result = await importStudentsFromExcel(file);
      toast.success(`Impor selesai: ${result.success} berhasil, ${result.failed} gagal`);
    } catch (err) {
      console.error(err);
      toast.error('Gagal mengimpor file Excel');
    } finally {
      setImporting(false);
      e.target.value = '';
    }
  };

  const handleDelete = async () => {
    if (!toDelete) return;
    try {
      await deleteStudent(toDelete.id);
      toast.success('Data santri berhasil dihapus');
    } catch {
      toast.error('Gagal menghapus data santri');
    } finally {
      setToDelete(null);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-gray-900 dark:text-white">Data Santri</h2>
          <p className="text-sm text-gray-500 dark:text-gray-400">{filtered.length} santri ditemukan</p>
        </div>
        {canEdit && (
          <div className="flex flex-wrap gap-2">
            <button onClick={() => fileInputRef.current?.click()} className="btn-secondary text-sm flex items-center gap-1.5" disabled={importing}>
              <Upload size={15} /> {importing ? 'Mengimpor...' : 'Import Excel'}
            </button>
            <input ref={fileInputRef} type="file" accept=".xlsx,.xls" onChange={handleImport} className="hidden" />
            <button onClick={() => exportStudentsToExcel(filtered)} className="btn-secondary text-sm flex items-center gap-1.5">
              <Download size={15} /> Export Excel
            </button>
            <button onClick={() => { setEditing(null); setFormOpen(true); }} className="btn-primary text-sm flex items-center gap-1.5">
              <Plus size={15} /> Tambah Santri
            </button>
          </div>
        )}
      </div>

      <div className="flex flex-col md:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
          <input
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(1); }}
            placeholder="Cari nama atau NIS..."
            className="input-field pl-9"
          />
        </div>
        <select className="input-field md:w-40" value={kelasFilter} onChange={(e) => { setKelasFilter(e.target.value); setPage(1); }}>
          <option value="">Semua Kelas</option>
          {kelasOptions.map((k) => <option key={k} value={k}>{k}</option>)}
        </select>
        <select className="input-field md:w-40" value={statusFilter} onChange={(e) => { setStatusFilter(e.target.value); setPage(1); }}>
          <option value="">Semua Status</option>
          <option value="aktif">Aktif</option>
          <option value="cuti">Cuti</option>
          <option value="lulus">Lulus</option>
          <option value="keluar">Keluar</option>
        </select>
      </div>

      <div className="card !p-0 overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-gray-400 border-b border-gray-100 dark:border-gray-700">
              <th className="py-3 px-4 font-medium">Santri</th>
              <th className="py-3 px-4 font-medium">NIS</th>
              <th className="py-3 px-4 font-medium">Kelas</th>
              <th className="py-3 px-4 font-medium">Kamar</th>
              <th className="py-3 px-4 font-medium">Status</th>
              <th className="py-3 px-4 font-medium text-right">Aksi</th>
            </tr>
          </thead>
          <tbody>
            {loading && Array.from({ length: 5 }).map((_, i) => <TableRowSkeleton key={i} cols={6} />)}
            {!loading && paginated.length === 0 && (
              <tr><td colSpan={6} className="text-center py-10 text-gray-400">Tidak ada data santri.</td></tr>
            )}
            {!loading && paginated.map((s) => (
              <tr key={s.id} className="border-b border-gray-50 dark:border-gray-700/50 hover:bg-gray-50/50 dark:hover:bg-gray-700/20">
                <td className="py-2.5 px-4">
                  <button onClick={() => navigate(`/santri/${s.id}`)} className="flex items-center gap-3 text-left hover:text-brand-600 group">
                    <img
                      src={s.foto || `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(s.nama || 'S')}`}
                      alt={s.nama}
                      className="w-9 h-9 rounded-full object-cover bg-gray-100"
                    />
                    <span className="font-medium text-gray-900 dark:text-white group-hover:text-brand-600 flex items-center gap-1">
                      {s.nama}
                      <ExternalLink size={12} className="opacity-0 group-hover:opacity-60" />
                    </span>
                  </button>
                </td>
                <td className="py-2.5 px-4 text-gray-500 dark:text-gray-400">{s.nis}</td>
                <td className="py-2.5 px-4 text-gray-500 dark:text-gray-400">{s.kelas}</td>
                <td className="py-2.5 px-4 text-gray-500 dark:text-gray-400">{s.kamar}</td>
                <td className="py-2.5 px-4">
                  <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                    s.status === 'aktif' ? 'bg-green-50 text-green-600 dark:bg-green-900/30' : 'bg-gray-100 text-gray-500 dark:bg-gray-700'
                  }`}>
                    {s.status}
                  </span>
                </td>
                <td className="py-2.5 px-4">
                  <div className="flex items-center justify-end gap-1">
                    <button onClick={() => setQrStudent(s)} className="p-2 text-gray-400 hover:text-brand-600" title="QR Code">
                      <QrCode size={16} />
                    </button>
                    {canEdit && (
                      <>
                        <button onClick={() => { setEditing(s); setFormOpen(true); }} className="p-2 text-gray-400 hover:text-brand-600" title="Edit">
                          <Pencil size={16} />
                        </button>
                        <button onClick={() => setToDelete(s)} className="p-2 text-gray-400 hover:text-red-600" title="Hapus">
                          <Trash2 size={16} />
                        </button>
                      </>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {totalPages > 1 && (
        <div className="flex items-center justify-between text-sm">
          <span className="text-gray-400">Halaman {page} dari {totalPages}</span>
          <div className="flex gap-2">
            <button disabled={page === 1} onClick={() => setPage((p) => p - 1)} className="btn-secondary p-2 disabled:opacity-40">
              <ChevronLeft size={16} />
            </button>
            <button disabled={page === totalPages} onClick={() => setPage((p) => p + 1)} className="btn-secondary p-2 disabled:opacity-40">
              <ChevronRight size={16} />
            </button>
          </div>
        </div>
      )}

      <StudentFormModal open={formOpen} onClose={() => setFormOpen(false)} student={editing} />
      <ConfirmDialog
        open={!!toDelete}
        title="Hapus Data Santri"
        message={`Yakin ingin menghapus data ${toDelete?.nama}? Tindakan ini tidak dapat dibatalkan.`}
        onConfirm={handleDelete}
        onCancel={() => setToDelete(null)}
      />

      {qrStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" onClick={() => setQrStudent(null)}>
          <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 flex flex-col items-center gap-3" onClick={(e) => e.stopPropagation()}>
            <QRCode value={qrStudent.nis || qrStudent.id} size={180} />
            <p className="font-semibold text-gray-900 dark:text-white">{qrStudent.nama}</p>
            <p className="text-xs text-gray-400">NIS: {qrStudent.nis}</p>
            <button onClick={() => setQrStudent(null)} className="btn-secondary text-sm mt-2">Tutup</button>
          </div>
        </div>
      )}
    </div>
  );
}
