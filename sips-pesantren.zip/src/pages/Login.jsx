import { useState } from 'react';
import { useNavigate, Navigate } from 'react-router-dom';
import { GraduationCap, Mail, Lock, Eye, EyeOff, HardDrive, Cloud } from 'lucide-react';
import toast from 'react-hot-toast';
import { useAuth } from '../context/AuthContext.jsx';
import { useDataMode } from '../context/DataModeContext.jsx';

const DEMO_ACCOUNTS = [
  { role: 'Admin', email: 'admin@demo.sips', password: 'admin123' },
  { role: 'Bendahara', email: 'bendahara@demo.sips', password: 'bendahara123' },
  { role: 'Musyrif/Ustadz', email: 'musyrif@demo.sips', password: 'musyrif123' },
  { role: 'Wali Santri', email: 'wali@demo.sips', password: 'wali123' }
];

export default function Login() {
  const { login, user, loading, resetPassword, mode: authMode } = useAuth();
  const { mode, switchMode, cloudConfigured } = useDataMode();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [errors, setErrors] = useState({});

  if (!loading && user) return <Navigate to="/" replace />;

  const validate = () => {
    const e = {};
    if (!email.trim()) e.email = 'Email wajib diisi';
    else if (!/\S+@\S+\.\S+/.test(email)) e.email = 'Format email tidak valid';
    if (!password) e.password = 'Kata sandi wajib diisi';
    else if (password.length < 6) e.password = 'Minimal 6 karakter';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async (ev) => {
    ev.preventDefault();
    if (!validate()) return;
    setSubmitting(true);
    try {
      await login(email.trim(), password);
      toast.success('Berhasil masuk');
      navigate('/');
    } catch (err) {
      const map = {
        'auth/invalid-credential': 'Email atau kata sandi salah',
        'auth/user-not-found': 'Akun tidak ditemukan',
        'auth/wrong-password': 'Kata sandi salah',
        'auth/too-many-requests': 'Terlalu banyak percobaan, coba lagi nanti'
      };
      toast.error(map[err.code] || 'Gagal masuk, periksa kembali data Anda');
    } finally {
      setSubmitting(false);
    }
  };

  const handleForgot = async () => {
    if (!email.trim()) {
      toast.error('Masukkan email terlebih dahulu untuk reset kata sandi');
      return;
    }
    try {
      const result = await resetPassword(email.trim());
      if (result?.localReset) {
        toast.success(`Kata sandi direset ke: ${result.tempPassword}`);
      } else {
        toast.success('Tautan reset kata sandi telah dikirim ke email Anda');
      }
    } catch {
      toast.error('Gagal mereset kata sandi, periksa kembali email Anda');
    }
  };

  const fillDemo = (acc) => {
    setEmail(acc.email);
    setPassword(acc.password);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-brand-50 to-white dark:from-gray-900 dark:to-gray-900 p-4">
      <div className="w-full max-w-sm">
        <div className="flex flex-col items-center mb-6">
          <div className="w-16 h-16 rounded-2xl bg-brand-600 flex items-center justify-center shadow-lg shadow-brand-600/20 mb-4">
            <GraduationCap className="text-white" size={30} />
          </div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">SIPS</h1>
          <p className="text-sm text-gray-500 dark:text-gray-400">Sistem Informasi Pesantren Santri</p>
        </div>

        <div className="grid grid-cols-2 gap-2 mb-4">
          <button
            type="button"
            onClick={() => switchMode('local')}
            className={`flex items-center justify-center gap-1.5 py-2.5 rounded-xl text-sm font-medium border-2 transition-colors ${
              mode === 'local' ? 'border-brand-600 bg-brand-50 dark:bg-brand-900/20 text-brand-700 dark:text-brand-400' : 'border-gray-200 dark:border-gray-700 text-gray-500'
            }`}
          >
            <HardDrive size={15} /> Mode Lokal
          </button>
          <button
            type="button"
            onClick={() => switchMode('cloud')}
            className={`flex items-center justify-center gap-1.5 py-2.5 rounded-xl text-sm font-medium border-2 transition-colors ${
              mode === 'cloud' ? 'border-brand-600 bg-brand-50 dark:bg-brand-900/20 text-brand-700 dark:text-brand-400' : 'border-gray-200 dark:border-gray-700 text-gray-500'
            }`}
          >
            <Cloud size={15} /> Mode Cloud
          </button>
        </div>

        {mode === 'local' && (
          <div className="card !p-3 mb-4 bg-amber-50/60 dark:bg-amber-900/10 border-amber-100 dark:border-amber-900/30">
            <p className="text-xs text-gray-600 dark:text-gray-300 mb-2">
              Mode Lokal: data hanya tersimpan di browser ini (untuk uji coba). Ketuk salah satu akun demo untuk mengisi form otomatis:
            </p>
            <div className="flex flex-wrap gap-1.5">
              {DEMO_ACCOUNTS.map((acc) => (
                <button
                  key={acc.email}
                  type="button"
                  onClick={() => fillDemo(acc)}
                  className="text-[11px] px-2.5 py-1 rounded-lg bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300"
                >
                  {acc.role}
                </button>
              ))}
            </div>
          </div>
        )}

        {mode === 'cloud' && !cloudConfigured && (
          <div className="card !p-3 mb-4 bg-red-50/60 dark:bg-red-900/10 border-red-100 dark:border-red-900/30">
            <p className="text-xs text-red-600 dark:text-red-400">
              Firebase belum dikonfigurasi. Isi file <code>.env</code> dengan konfigurasi proyek Firebase Anda, lalu jalankan ulang aplikasi. Lihat README untuk panduan lengkap.
            </p>
          </div>
        )}

        <form onSubmit={handleSubmit} className="card space-y-4" noValidate>
          <div>
            <label className="label-field">Email</label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={17} />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="nama@pesantren.id"
                className="input-field pl-10"
                autoComplete="username"
              />
            </div>
            {errors.email && <p className="text-xs text-red-500 mt-1">{errors.email}</p>}
          </div>

          <div>
            <label className="label-field">Kata Sandi</label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={17} />
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="input-field pl-10 pr-10"
                autoComplete="current-password"
              />
              <button
                type="button"
                onClick={() => setShowPassword((s) => !s)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"
              >
                {showPassword ? <EyeOff size={17} /> : <Eye size={17} />}
              </button>
            </div>
            {errors.password && <p className="text-xs text-red-500 mt-1">{errors.password}</p>}
          </div>

          <button type="button" onClick={handleForgot} className="text-xs text-brand-600 font-medium">
            Lupa kata sandi?
          </button>

          <button type="submit" disabled={submitting} className="btn-primary w-full">
            {submitting ? 'Memproses...' : 'Masuk'}
          </button>
        </form>

        <p className="text-center text-xs text-gray-400 mt-6">
          Akun dibuat oleh Admin pesantren. Hubungi admin jika belum memiliki akun.
        </p>
      </div>
    </div>
  );
}
