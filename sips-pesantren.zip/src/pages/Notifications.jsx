import { Bell, BellOff } from 'lucide-react';
import { useFirestoreCollection } from '../hooks/useFirestoreCollection';
import { formatTanggalSingkat } from '../utils/format.js';

export default function Notifications() {
  const { data: notifications, loading } = useFirestoreCollection('notifications', 'createdAt', 'desc');

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-xl font-bold text-gray-900 dark:text-white">Notifikasi</h2>
        <p className="text-sm text-gray-500 dark:text-gray-400">Pemberitahuan otomatis sistem</p>
      </div>

      <div className="space-y-2">
        {loading && <p className="text-center text-gray-400 py-8 text-sm">Memuat notifikasi...</p>}
        {!loading && notifications.length === 0 && (
          <div className="card text-center py-12 text-gray-400">
            <BellOff className="mx-auto mb-2 text-gray-300" size={28} />
            Belum ada notifikasi.
          </div>
        )}
        {!loading && notifications.map((n) => (
          <div key={n.id} className="card flex items-start gap-3">
            <div className="w-9 h-9 rounded-xl bg-brand-50 dark:bg-brand-900/30 flex items-center justify-center shrink-0">
              <Bell size={16} className="text-brand-600" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-gray-900 dark:text-white">{n.judul || 'Notifikasi'}</p>
              <p className="text-sm text-gray-500 dark:text-gray-400">{n.pesan}</p>
              <p className="text-xs text-gray-400 mt-1">{formatTanggalSingkat(n.createdAt)}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
