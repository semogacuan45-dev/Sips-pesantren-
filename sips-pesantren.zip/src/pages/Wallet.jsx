import { useMemo, useState } from 'react';
import { Wallet as WalletIcon, ArrowDownCircle, ArrowUpCircle, Send, ShoppingBag, Search, AlertCircle } from 'lucide-react';
import { useFirestoreCollection } from '../hooks/useFirestoreCollection';
import { CardSkeleton } from '../components/Skeleton.jsx';
import WalletTransactionModal from '../components/WalletTransactionModal.jsx';
import { formatRupiah } from '../utils/format.js';
import { useAuth } from '../context/AuthContext.jsx';

export default function WalletPage() {
  const SALDO_MENIPIS = 10000;
  const { isAdmin, isBendahara, profile } = useAuth();
  const canManage = isAdmin || isBendahara;
  const { data: students } = useFirestoreCollection('students', 'nama', 'asc');
  const { data: wallets, loading } = useFirestoreCollection('wallets');

  const [search, setSearch] = useState('');
  const [modal, setModal] = useState({ open: false, student: null, type: 'masuk' });

  const walletMap = useMemo(() => {
    const m = {};
    wallets.forEach((w) => { m[w.studentId || w.id] = w; });
    return m;
  }, [wallets]);

  const scopedStudents = useMemo(() => {
    let list = students;
    if (profile?.role === 'wali' && profile?.studentId) {
      list = list.filter((s) => s.id === profile.studentId);
    }
    if (search) list = list.filter((s) => s.nama?.toLowerCase().includes(search.toLowerCase()));
    return list;
  }, [students, search, profile]);

  const totalSaldo = wallets.reduce((sum, w) => sum + (w.saldo || 0), 0);

  const openModal = (student, type) => setModal({ open: true, student, type });

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-xl font-bold text-gray-900 dark:text-white">Uang Jajan Santri</h2>
        <p className="text-sm text-gray-500 dark:text-gray-400">Kelola dompet digital santri</p>
      </div>

      {canManage && (
        <div className="card bg-gradient-to-br from-brand-600 to-brand-700 text-white !p-5">
          <div className="flex items-center gap-2 mb-1">
            <WalletIcon size={18} />
            <span className="text-sm opacity-90">Total Saldo Seluruh Santri</span>
          </div>
          <p className="text-3xl font-bold">{formatRupiah(totalSaldo)}</p>
        </div>
      )}

      {profile?.role !== 'wali' && (
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Cari nama santri..." className="input-field pl-9" />
        </div>
      )}

      <div className="grid md:grid-cols-2 gap-3">
        {loading && Array.from({ length: 4 }).map((_, i) => <CardSkeleton key={i} />)}
        {!loading && scopedStudents.map((s) => {
          const wallet = walletMap[s.id];
          const saldo = wallet?.saldo || 0;
          return (
            <div key={s.id} className="card space-y-3">
              <div className="flex items-center gap-3">
                <img
                  src={s.foto || `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(s.nama || 'S')}`}
                  alt={s.nama}
                  className="w-10 h-10 rounded-full object-cover bg-gray-100"
                />
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-gray-900 dark:text-white text-sm truncate">{s.nama}</p>
                  <p className="text-xs text-gray-400">{s.kelas}</p>
                </div>
                <div className="text-right">
                  <p className="text-lg font-bold text-brand-600">{formatRupiah(saldo)}</p>
                  {saldo > 0 && saldo < SALDO_MENIPIS && (
                    <span className="inline-flex items-center gap-1 text-[10px] font-medium text-amber-600 bg-amber-50 dark:bg-amber-900/20 px-1.5 py-0.5 rounded-full">
                      <AlertCircle size={10} /> Saldo menipis
                    </span>
                  )}
                </div>
              </div>
              {canManage && (
                <div className="grid grid-cols-4 gap-1.5">
                  <button onClick={() => openModal(s, 'masuk')} className="flex flex-col items-center gap-1 py-2 rounded-xl bg-green-50 dark:bg-green-900/20 text-green-600 text-[11px] font-medium">
                    <ArrowDownCircle size={16} /> Top Up
                  </button>
                  <button onClick={() => openModal(s, 'keluar')} className="flex flex-col items-center gap-1 py-2 rounded-xl bg-red-50 dark:bg-red-900/20 text-red-600 text-[11px] font-medium">
                    <ArrowUpCircle size={16} /> Tarik
                  </button>
                  <button onClick={() => openModal(s, 'jajan')} className="flex flex-col items-center gap-1 py-2 rounded-xl bg-amber-50 dark:bg-amber-900/20 text-amber-600 text-[11px] font-medium">
                    <ShoppingBag size={16} /> Jajan
                  </button>
                  <button onClick={() => openModal(s, 'transfer')} className="flex flex-col items-center gap-1 py-2 rounded-xl bg-blue-50 dark:bg-blue-900/20 text-blue-600 text-[11px] font-medium">
                    <Send size={16} /> Transfer
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </div>

      <WalletTransactionModal
        open={modal.open}
        onClose={() => setModal({ open: false, student: null, type: 'masuk' })}
        student={modal.student}
        students={students}
        type={modal.type}
      />
    </div>
  );
}
