import { useState } from 'react';
import { Plus, Pencil, Trash2, AlertTriangle, Wallet } from 'lucide-react';
import toast from 'react-hot-toast';
import { useFirestoreCollection } from '../hooks/useFirestoreCollection';
import { createRecordService } from '../services/recordService';
import { processWalletTransaction } from '../services/walletService';
import SimpleRecordFormModal from '../components/SimpleRecordFormModal.jsx';
import ConfirmDialog from '../components/ConfirmDialog.jsx';
import { TableRowSkeleton } from '../components/Skeleton.jsx';
import { formatTanggalSingkat, formatRupiah } from '../utils/format.js';
import { useAuth } from '../context/AuthContext.jsx';

const service = createRecordService('violations');
const KATEGORI_OPTS = ['Ringan', 'Sedang', 'Berat'];
const SARAN_DENDA = { Ringan: 5000, Sedang: 15000, Berat: 50000 };

const FIELDS = [
  { key: 'tanggal', label: 'Tanggal', type: 'date', required: true, default: new Date().toISOString().slice(0, 10) },
  { key: 'kategori', label: 'Kategori', type: 'select', options: KATEGORI_OPTS, required: true, default: 'Ringan' },
  { key: 'poin', label: 'Poin Pelanggaran', type: 'number', required: true, default: 5 },
  { key: 'denda', label: 'Denda (Rp) — isi untuk potong saldo otomatis, kosongkan/0 jika tidak ada denda', type: 'number', default: 0 },
  { key: 'catatan', label: 'Catatan Kejadian', type: 'textarea', required: true },
  { key: 'foto', label: 'Foto Bukti', type: 'photo' }
];

const KATEGORI_COLOR = { Ringan: 'bg-amber-50 text-amber-600', Sedang: 'bg-orange-50 text-orange-600', Berat: 'bg-red-50 text-red-600' };

export default function Violations() {
  const { isAdmin, isMusyrif, profile } = useAuth();
  const canEdit = isAdmin || isMusyrif;
  const { data: students } = useFirestoreCollection('students', 'nama', 'asc');
  const { data: entries, loading } = useFirestoreCollection('violations', 'tanggal', 'desc');
  const scoped = profile?.role === 'wali' && profile?.studentId ? entries.filter((e) => e.studentId === profile.studentId) : entries;

  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [toDelete, setToDelete] = useState(null);

  const handleDelete = async () => {
    try {
      await service.remove(toDelete.id);
      toast.success('Data pelanggaran berhasil dihapus');
    } catch {
      toast.error('Gagal menghapus data');
    } finally {
      setToDelete(null);
    }
  };

  // Integrasi: jika denda diisi, otomatis potong saldo uang jajan santri terkait.
  const handleAfterSave = async (payload) => {
    const nominal = Number(payload.denda) || 0;
    if (nominal <= 0) return;
    try {
      await processWalletTransaction({
        studentId: payload.studentId,
        studentName: payload.studentName,
        jenis: 'keluar',
        nominal,
        catatan: `Denda pelanggaran (${payload.kategori}): ${payload.catatan?.slice(0, 60) || '-'}`,
        createdBy: profile?.name
      });
      toast.success(`Saldo ${payload.studentName} otomatis dipotong ${formatRupiah(nominal)}`);
    } catch (err) {
      toast.error(err.message === 'Saldo tidak mencukupi' ? `Saldo ${payload.studentName} tidak mencukupi untuk denda ini` : 'Gagal memotong saldo otomatis');
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-gray-900 dark:text-white">Pelanggaran Santri</h2>
          <p className="text-sm text-gray-500 dark:text-gray-400">{scoped.length} catatan pelanggaran</p>
        </div>
        {canEdit && (
          <button onClick={() => { setEditing(null); setFormOpen(true); }} className="btn-primary text-sm flex items-center gap-1.5 self-start">
            <Plus size={15} /> Catat Pelanggaran
          </button>
        )}
      </div>

      {canEdit && (
        <div className="card !p-3 bg-blue-50/60 dark:bg-blue-900/10 border-blue-100 dark:border-blue-900/30 flex items-start gap-2">
          <Wallet size={16} className="text-blue-500 mt-0.5 shrink-0" />
          <p className="text-xs text-gray-600 dark:text-gray-300">
            Saran denda otomatis: Ringan {formatRupiah(SARAN_DENDA.Ringan)}, Sedang {formatRupiah(SARAN_DENDA.Sedang)}, Berat {formatRupiah(SARAN_DENDA.Berat)}.
            Isi kolom "Denda" saat mencatat pelanggaran untuk memotong saldo Uang Jajan santri secara otomatis.
          </p>
        </div>
      )}

      <div className="space-y-2">
        {loading && Array.from({ length: 3 }).map((_, i) => <div key={i} className="card"><TableRowSkeleton cols={1} /></div>)}
        {!loading && scoped.length === 0 && (
          <div className="card text-center py-10 text-gray-400"><AlertTriangle className="mx-auto mb-2 text-gray-300" size={28} />Belum ada catatan pelanggaran.</div>
        )}
        {!loading && scoped.map((e) => (
          <div key={e.id} className="card flex items-start gap-3">
            {e.foto && <img src={e.foto} alt="bukti" className="w-14 h-14 rounded-xl object-cover shrink-0" />}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap mb-1">
                <span className="font-medium text-gray-900 dark:text-white text-sm">{e.studentName}</span>
                <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${KATEGORI_COLOR[e.kategori] || 'bg-gray-100 text-gray-500'}`}>{e.kategori}</span>
                <span className="text-xs text-gray-400">{e.poin} poin</span>
                {Number(e.denda) > 0 && (
                  <span className="text-xs px-2 py-0.5 rounded-full font-medium bg-red-50 text-red-600 dark:bg-red-900/20">Denda {formatRupiah(e.denda)}</span>
                )}
              </div>
              <p className="text-sm text-gray-500 dark:text-gray-400">{e.catatan}</p>
              <p className="text-xs text-gray-400 mt-1">{formatTanggalSingkat(e.tanggal)}</p>
            </div>
            {canEdit && (
              <div className="flex gap-1 shrink-0">
                <button onClick={() => { setEditing(e); setFormOpen(true); }} className="p-2 text-gray-400 hover:text-brand-600"><Pencil size={16} /></button>
                <button onClick={() => setToDelete(e)} className="p-2 text-gray-400 hover:text-red-600"><Trash2 size={16} /></button>
              </div>
            )}
          </div>
        ))}
      </div>

      <SimpleRecordFormModal
        open={formOpen} onClose={() => setFormOpen(false)} title={editing ? 'Edit Pelanggaran' : 'Catat Pelanggaran'}
        fields={FIELDS} students={students} service={service} entry={editing} photoFolder="violations"
        onAfterSave={handleAfterSave}
      />
      <ConfirmDialog open={!!toDelete} title="Hapus Data Pelanggaran" message="Yakin ingin menghapus catatan ini? (Saldo yang sudah terpotong tidak otomatis dikembalikan)" onConfirm={handleDelete} onCancel={() => setToDelete(null)} />
    </div>
  );
}
