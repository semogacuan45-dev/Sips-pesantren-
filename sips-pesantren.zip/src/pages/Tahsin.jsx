import { useState } from 'react';
import { Plus, Pencil, Trash2, GraduationCap } from 'lucide-react';
import toast from 'react-hot-toast';
import { useFirestoreCollection } from '../hooks/useFirestoreCollection';
import { createRecordService } from '../services/recordService';
import SimpleRecordFormModal from '../components/SimpleRecordFormModal.jsx';
import ConfirmDialog from '../components/ConfirmDialog.jsx';
import { TableRowSkeleton } from '../components/Skeleton.jsx';
import { formatTanggalSingkat } from '../utils/format.js';
import { useAuth } from '../context/AuthContext.jsx';

const service = createRecordService('tahsin');
const NILAI_OPTS = ['Sangat Baik', 'Baik', 'Cukup', 'Perlu Perbaikan'];

const FIELDS = [
  { key: 'tanggal', label: 'Tanggal', type: 'date', required: true, default: new Date().toISOString().slice(0, 10) },
  { key: 'makhraj', label: 'Makhraj', type: 'select', options: NILAI_OPTS, default: 'Baik' },
  { key: 'sifatHuruf', label: 'Sifat Huruf', type: 'select', options: NILAI_OPTS, default: 'Baik' },
  { key: 'mad', label: 'Mad', type: 'select', options: NILAI_OPTS, default: 'Baik' },
  { key: 'ghunnah', label: 'Ghunnah', type: 'select', options: NILAI_OPTS, default: 'Baik' },
  { key: 'kelancaran', label: 'Kelancaran', type: 'select', options: NILAI_OPTS, default: 'Baik' },
  { key: 'catatan', label: 'Catatan', type: 'textarea' }
];

export default function Tahsin() {
  const { isAdmin, isMusyrif, profile } = useAuth();
  const canEdit = isAdmin || isMusyrif;
  const { data: students } = useFirestoreCollection('students', 'nama', 'asc');
  const { data: entries, loading } = useFirestoreCollection('tahsin', 'tanggal', 'desc');

  const scoped = profile?.role === 'wali' && profile?.studentId ? entries.filter((e) => e.studentId === profile.studentId) : entries;

  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [toDelete, setToDelete] = useState(null);

  const handleDelete = async () => {
    try {
      await service.remove(toDelete.id);
      toast.success('Data tahsin berhasil dihapus');
    } catch {
      toast.error('Gagal menghapus data');
    } finally {
      setToDelete(null);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-gray-900 dark:text-white">Penilaian Tahsin</h2>
          <p className="text-sm text-gray-500 dark:text-gray-400">{scoped.length} catatan penilaian</p>
        </div>
        {canEdit && (
          <button onClick={() => { setEditing(null); setFormOpen(true); }} className="btn-primary text-sm flex items-center gap-1.5 self-start">
            <Plus size={15} /> Input Nilai Tahsin
          </button>
        )}
      </div>

      <div className="card !p-0 overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-gray-400 border-b border-gray-100 dark:border-gray-700">
              <th className="py-3 px-4 font-medium">Tanggal</th>
              <th className="py-3 px-4 font-medium">Santri</th>
              <th className="py-3 px-4 font-medium">Makhraj</th>
              <th className="py-3 px-4 font-medium">Mad</th>
              <th className="py-3 px-4 font-medium">Kelancaran</th>
              {canEdit && <th className="py-3 px-4 font-medium text-right">Aksi</th>}
            </tr>
          </thead>
          <tbody>
            {loading && Array.from({ length: 5 }).map((_, i) => <TableRowSkeleton key={i} cols={6} />)}
            {!loading && scoped.length === 0 && (
              <tr><td colSpan={6} className="text-center py-10 text-gray-400"><GraduationCap className="mx-auto mb-2 text-gray-300" size={28} />Belum ada catatan tahsin.</td></tr>
            )}
            {!loading && scoped.slice(0, 50).map((e) => (
              <tr key={e.id} className="border-b border-gray-50 dark:border-gray-700/50">
                <td className="py-2.5 px-4 text-gray-500 dark:text-gray-400 whitespace-nowrap">{formatTanggalSingkat(e.tanggal)}</td>
                <td className="py-2.5 px-4 font-medium text-gray-900 dark:text-white">{e.studentName}</td>
                <td className="py-2.5 px-4 text-gray-500 dark:text-gray-400">{e.makhraj}</td>
                <td className="py-2.5 px-4 text-gray-500 dark:text-gray-400">{e.mad}</td>
                <td className="py-2.5 px-4 text-gray-500 dark:text-gray-400">{e.kelancaran}</td>
                {canEdit && (
                  <td className="py-2.5 px-4">
                    <div className="flex items-center justify-end gap-1">
                      <button onClick={() => { setEditing(e); setFormOpen(true); }} className="p-2 text-gray-400 hover:text-brand-600"><Pencil size={16} /></button>
                      <button onClick={() => setToDelete(e)} className="p-2 text-gray-400 hover:text-red-600"><Trash2 size={16} /></button>
                    </div>
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <SimpleRecordFormModal
        open={formOpen} onClose={() => setFormOpen(false)} title={editing ? 'Edit Nilai Tahsin' : 'Input Nilai Tahsin'}
        fields={FIELDS} students={students} service={service} entry={editing} photoFolder="tahsin"
      />
      <ConfirmDialog open={!!toDelete} title="Hapus Data Tahsin" message="Yakin ingin menghapus catatan ini?" onConfirm={handleDelete} onCancel={() => setToDelete(null)} />
    </div>
  );
}
