import { useMemo, useState } from 'react';
import { FileDown, FileSpreadsheet, Printer } from 'lucide-react';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';
import { useFirestoreCollection } from '../hooks/useFirestoreCollection';
import { formatTanggalSingkat } from '../utils/format.js';

const PERIODE_OPTS = [
  { value: 'harian', label: 'Harian' },
  { value: 'mingguan', label: 'Mingguan' },
  { value: 'bulanan', label: 'Bulanan' },
  { value: 'semester', label: 'Semester' },
  { value: 'tahunan', label: 'Tahunan' }
];

const JENIS_OPTS = [
  { value: 'tahfidz', label: 'Laporan Hafalan' },
  { value: 'attendance', label: 'Laporan Absensi' },
  { value: 'transactions', label: 'Laporan Keuangan' }
];

function filterByPeriode(items, periode, dateField = 'tanggal') {
  const now = new Date();
  const cutoff = new Date(now);
  if (periode === 'harian') cutoff.setDate(now.getDate() - 1);
  else if (periode === 'mingguan') cutoff.setDate(now.getDate() - 7);
  else if (periode === 'bulanan') cutoff.setMonth(now.getMonth() - 1);
  else if (periode === 'semester') cutoff.setMonth(now.getMonth() - 6);
  else if (periode === 'tahunan') cutoff.setFullYear(now.getFullYear() - 1);

  return items.filter((it) => {
    const raw = it[dateField];
    const d = raw?.toDate ? raw.toDate() : raw ? new Date(raw) : null;
    return d && d >= cutoff;
  });
}

export default function Reports() {
  const [jenis, setJenis] = useState('tahfidz');
  const [periode, setPeriode] = useState('mingguan');

  const { data: tahfidz } = useFirestoreCollection('tahfidz', 'tanggal', 'desc');
  const { data: attendance } = useFirestoreCollection('attendance', 'tanggal', 'desc');
  const { data: transactions } = useFirestoreCollection('transactions', 'createdAt', 'desc');

  const sourceMap = { tahfidz, attendance, transactions };
  const dateFieldMap = { tahfidz: 'tanggal', attendance: 'tanggal', transactions: 'createdAt' };

  const rows = useMemo(() => filterByPeriode(sourceMap[jenis] || [], periode, dateFieldMap[jenis]), [jenis, periode, tahfidz, attendance, transactions]);

  const columns = useMemo(() => {
    if (jenis === 'tahfidz') return [
      { header: 'Tanggal', key: 'tanggal', fmt: (v) => formatTanggalSingkat(v) },
      { header: 'Santri', key: 'studentName' },
      { header: 'Surat', key: 'surat' },
      { header: 'Nilai', key: 'nilai' },
      { header: 'Kelancaran', key: 'kelancaran' }
    ];
    if (jenis === 'attendance') return [
      { header: 'Tanggal', key: 'tanggal', fmt: (v) => formatTanggalSingkat(v) },
      { header: 'Santri', key: 'studentName' },
      { header: 'Status', key: 'status' }
    ];
    return [
      { header: 'Tanggal', key: 'createdAt', fmt: (v) => formatTanggalSingkat(v) },
      { header: 'Santri', key: 'studentName' },
      { header: 'Jenis', key: 'jenis' },
      { header: 'Nominal', key: 'nominal' }
    ];
  }, [jenis]);

  const title = `Laporan ${JENIS_OPTS.find((j) => j.value === jenis)?.label} - Periode ${PERIODE_OPTS.find((p) => p.value === periode)?.label}`;

  const handleExportPDF = () => {
    const docPdf = new jsPDF();
    docPdf.setFontSize(14);
    docPdf.text('SIPS - Sistem Informasi Pesantren Santri', 14, 15);
    docPdf.setFontSize(11);
    docPdf.text(title, 14, 22);
    autoTable(docPdf, {
      startY: 28,
      head: [columns.map((c) => c.header)],
      body: rows.map((r) => columns.map((c) => (c.fmt ? c.fmt(r[c.key]) : r[c.key] ?? '-'))),
      styles: { fontSize: 9 },
      headStyles: { fillColor: [5, 150, 105] }
    });
    docPdf.save(`${jenis}-${periode}.pdf`);
  };

  const handleExportExcel = () => {
    const data = rows.map((r) => {
      const obj = {};
      columns.forEach((c) => { obj[c.header] = c.fmt ? c.fmt(r[c.key]) : r[c.key] ?? '-'; });
      return obj;
    });
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Laporan');
    XLSX.writeFile(wb, `${jenis}-${periode}.xlsx`);
  };

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-xl font-bold text-gray-900 dark:text-white">Laporan</h2>
        <p className="text-sm text-gray-500 dark:text-gray-400">Buat laporan periodik dan ekspor ke PDF/Excel</p>
      </div>

      <div className="flex flex-col md:flex-row gap-3 no-print">
        <select className="input-field md:w-56" value={jenis} onChange={(e) => setJenis(e.target.value)}>
          {JENIS_OPTS.map((j) => <option key={j.value} value={j.value}>{j.label}</option>)}
        </select>
        <select className="input-field md:w-56" value={periode} onChange={(e) => setPeriode(e.target.value)}>
          {PERIODE_OPTS.map((p) => <option key={p.value} value={p.value}>{p.label}</option>)}
        </select>
        <div className="flex gap-2 md:ml-auto">
          <button onClick={handleExportPDF} className="btn-secondary text-sm flex items-center gap-1.5"><FileDown size={15} /> PDF</button>
          <button onClick={handleExportExcel} className="btn-secondary text-sm flex items-center gap-1.5"><FileSpreadsheet size={15} /> Excel</button>
          <button onClick={() => window.print()} className="btn-primary text-sm flex items-center gap-1.5"><Printer size={15} /> Print</button>
        </div>
      </div>

      <div className="card !p-0 overflow-x-auto">
        <div className="p-4 border-b border-gray-100 dark:border-gray-700">
          <h3 className="font-semibold text-gray-900 dark:text-white">{title}</h3>
          <p className="text-xs text-gray-400">{rows.length} data</p>
        </div>
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-gray-400 border-b border-gray-100 dark:border-gray-700">
              {columns.map((c) => <th key={c.key} className="py-3 px-4 font-medium">{c.header}</th>)}
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 && <tr><td colSpan={columns.length} className="text-center py-10 text-gray-400">Tidak ada data untuk periode ini.</td></tr>}
            {rows.slice(0, 200).map((r, idx) => (
              <tr key={r.id || idx} className="border-b border-gray-50 dark:border-gray-700/50">
                {columns.map((c) => (
                  <td key={c.key} className="py-2.5 px-4 text-gray-600 dark:text-gray-300">{c.fmt ? c.fmt(r[c.key]) : r[c.key] ?? '-'}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
