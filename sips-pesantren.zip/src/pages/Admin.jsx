import { useRef, useState } from 'react';
import { UserPlus, Building2, DoorOpen, DownloadCloud, UploadCloud, KeyRound, Trash2, Database, Cloud, HardDrive } from 'lucide-react';
import toast from 'react-hot-toast';
import { useFirestoreCollection } from '../hooks/useFirestoreCollection';
import { createUserAccount, resetUserPassword, classService, roomService, backupAllData, restoreFromBackupFile } from '../services/adminService';
import ConfirmDialog from '../components/ConfirmDialog.jsx';
import { useDataMode } from '../context/DataModeContext.jsx';
import { estimateSizeKB, clearAll, seedDemoData } from '../data/localStore';

const TABS = [
  { key: 'mode', label: 'Mode & Data' },
  { key: 'users', label: 'Guru & Akun' },
  { key: 'kelas', label: 'Kelas' },
  { key: 'kamar', label: 'Kamar' },
  { key: 'backup', label: 'Backup & Restore' }
];

export default function Admin() {
  const [tab, setTab] = useState('users');
  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-xl font-bold text-gray-900 dark:text-white">Panel Admin</h2>
        <p className="text-sm text-gray-500 dark:text-gray-400">Kelola guru, kelas, kamar, dan data sistem</p>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-1">
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-colors ${
              tab === t.key ? 'bg-brand-600 text-white' : 'bg-white dark:bg-gray-800 text-gray-500 dark:text-gray-300 border border-gray-100 dark:border-gray-700'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'mode' && <ModeTab />}
      {tab === 'users' && <UsersTab />}
      {tab === 'kelas' && <SimpleListTab title="Kelas" icon={Building2} collectionName="classes" service={classService} placeholder="Contoh: 8A" />}
      {tab === 'kamar' && <SimpleListTab title="Kamar" icon={DoorOpen} collectionName="rooms" service={roomService} placeholder="Contoh: Kamar 3" />}
      {tab === 'backup' && <BackupTab />}
    </div>
  );
}

function ModeTab() {
  const { mode, switchMode, cloudConfigured } = useDataMode();
  const [confirmSwitch, setConfirmSwitch] = useState(null); // 'local' | 'cloud' | null
  const [confirmClear, setConfirmClear] = useState(false);
  const sizeKB = estimateSizeKB();

  const handleSwitch = (target) => {
    if (target === mode) return;
    setConfirmSwitch(target);
  };

  const doSwitch = () => {
    switchMode(confirmSwitch);
    toast.success(`Berpindah ke Mode ${confirmSwitch === 'local' ? 'Lokal' : 'Cloud'}`);
    setConfirmSwitch(null);
  };

  const doClear = () => {
    clearAll();
    seedDemoData();
    toast.success('Data lokal dikosongkan & akun demo dibuat ulang. Anda akan logout.');
    setConfirmClear(false);
    setTimeout(() => window.location.reload(), 800);
  };

  return (
    <div className="space-y-4">
      <div className="card space-y-3">
        <h3 className="font-semibold text-gray-900 dark:text-white flex items-center gap-2"><Database size={17} /> Mode Penyimpanan Data</h3>
        <p className="text-sm text-gray-500 dark:text-gray-400">
          Saat ini aplikasi berjalan di <span className="font-semibold text-brand-600">Mode {mode === 'local' ? 'Lokal' : 'Cloud'}</span>.
          Berpindah mode akan logout otomatis karena data & akun tersimpan terpisah di masing-masing mode.
        </p>
        <div className="grid md:grid-cols-2 gap-3">
          <button
            onClick={() => handleSwitch('local')}
            className={`text-left p-4 rounded-xl border-2 transition-colors ${mode === 'local' ? 'border-brand-600 bg-brand-50 dark:bg-brand-900/20' : 'border-gray-100 dark:border-gray-700'}`}
          >
            <div className="flex items-center gap-2 mb-1"><HardDrive size={16} className="text-brand-600" /><span className="font-medium text-gray-900 dark:text-white">Mode Lokal</span></div>
            <p className="text-xs text-gray-500 dark:text-gray-400">Data tersimpan di browser HP/PC ini saja. Tanpa setup Firebase, tanpa sinkron antar perangkat. Cocok untuk uji coba.</p>
          </button>
          <button
            onClick={() => handleSwitch('cloud')}
            className={`text-left p-4 rounded-xl border-2 transition-colors ${mode === 'cloud' ? 'border-brand-600 bg-brand-50 dark:bg-brand-900/20' : 'border-gray-100 dark:border-gray-700'}`}
          >
            <div className="flex items-center gap-2 mb-1"><Cloud size={16} className="text-brand-600" /><span className="font-medium text-gray-900 dark:text-white">Mode Cloud</span></div>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              Data tersimpan di Firebase, real-time & tersinkron di semua perangkat/pengguna. {!cloudConfigured && <span className="text-amber-600 font-medium">Firebase belum dikonfigurasi (isi .env).</span>}
            </p>
          </button>
        </div>
      </div>

      {mode === 'local' && (
        <div className="card space-y-3">
          <h3 className="font-semibold text-gray-900 dark:text-white">Penyimpanan Lokal</h3>
          <p className="text-sm text-gray-500 dark:text-gray-400">Perkiraan pemakaian: <span className="font-medium">{sizeKB} KB</span> dari batas browser (umumnya 5-10 MB).</p>
          <button onClick={() => setConfirmClear(true)} className="btn-secondary text-sm text-red-600 flex items-center gap-1.5 w-fit">
            <Trash2 size={15} /> Kosongkan Data Lokal
          </button>
        </div>
      )}

      <ConfirmDialog
        open={!!confirmSwitch}
        title="Pindah Mode Data"
        message={`Yakin ingin pindah ke Mode ${confirmSwitch === 'local' ? 'Lokal' : 'Cloud'}? Anda akan logout dan perlu masuk kembali dengan akun mode tersebut.`}
        danger={false}
        onConfirm={doSwitch}
        onCancel={() => setConfirmSwitch(null)}
      />
      <ConfirmDialog
        open={confirmClear}
        title="Kosongkan Data Lokal"
        message="Semua data di Mode Lokal (santri, hafalan, absensi, keuangan, dll) akan dihapus permanen dari browser ini. Lanjutkan?"
        onConfirm={doClear}
        onCancel={() => setConfirmClear(false)}
      />
    </div>
  );
}

function UsersTab() {
  const { data: students } = useFirestoreCollection('students', 'nama', 'asc');
  const { data: users, loading } = useFirestoreCollection('users');
  const [form, setForm] = useState({ email: '', password: '', name: '', role: 'musyrif', studentId: '' });
  const [saving, setSaving] = useState(false);

  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));

  const handleCreate = async (e) => {
    e.preventDefault();
    if (!form.email || !form.password || !form.name) {
      toast.error('Lengkapi semua data akun');
      return;
    }
    setSaving(true);
    try {
      await createUserAccount(form);
      toast.success('Akun berhasil dibuat');
      setForm({ email: '', password: '', name: '', role: 'musyrif', studentId: '' });
    } catch (err) {
      const map = { 'auth/email-already-in-use': 'Email sudah terdaftar', 'auth/weak-password': 'Kata sandi terlalu lemah (min 6 karakter)' };
      toast.error(map[err.code] || 'Gagal membuat akun');
    } finally {
      setSaving(false);
    }
  };

  const handleReset = async (email) => {
    try {
      const result = await resetUserPassword(email);
      if (result?.localReset) {
        toast.success(`Kata sandi direset ke: ${result.tempPassword}`);
      } else {
        toast.success(`Email reset kata sandi dikirim ke ${email}`);
      }
    } catch {
      toast.error('Gagal mereset kata sandi');
    }
  };

  return (
    <div className="grid md:grid-cols-2 gap-4">
      <form onSubmit={handleCreate} className="card space-y-3">
        <h3 className="font-semibold text-gray-900 dark:text-white flex items-center gap-2"><UserPlus size={17} /> Tambah Akun Pengguna</h3>
        <div>
          <label className="label-field">Nama Lengkap</label>
          <input className="input-field" value={form.name} onChange={set('name')} />
        </div>
        <div>
          <label className="label-field">Email</label>
          <input type="email" className="input-field" value={form.email} onChange={set('email')} />
        </div>
        <div>
          <label className="label-field">Kata Sandi Awal</label>
          <input type="password" className="input-field" value={form.password} onChange={set('password')} placeholder="Minimal 6 karakter" />
        </div>
        <div>
          <label className="label-field">Peran (Role)</label>
          <select className="input-field" value={form.role} onChange={set('role')}>
            <option value="admin">Admin</option>
            <option value="bendahara">Bendahara</option>
            <option value="musyrif">Musyrif/Ustadz</option>
            <option value="wali">Wali Santri</option>
          </select>
        </div>
        {form.role === 'wali' && (
          <div>
            <label className="label-field">Hubungkan dengan Santri</label>
            <select className="input-field" value={form.studentId} onChange={set('studentId')}>
              <option value="">Pilih Santri</option>
              {students.map((s) => <option key={s.id} value={s.id}>{s.nama} ({s.nis})</option>)}
            </select>
          </div>
        )}
        <button type="submit" disabled={saving} className="btn-primary w-full">{saving ? 'Membuat akun...' : 'Buat Akun'}</button>
      </form>

      <div className="card !p-0 overflow-x-auto">
        <div className="p-4 border-b border-gray-100 dark:border-gray-700"><h3 className="font-semibold text-gray-900 dark:text-white">Daftar Pengguna</h3></div>
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-gray-400 border-b border-gray-100 dark:border-gray-700">
              <th className="py-2.5 px-4 font-medium">Nama</th>
              <th className="py-2.5 px-4 font-medium">Peran</th>
              <th className="py-2.5 px-4 font-medium text-right">Aksi</th>
            </tr>
          </thead>
          <tbody>
            {!loading && users.map((u) => (
              <tr key={u.id} className="border-b border-gray-50 dark:border-gray-700/50">
                <td className="py-2.5 px-4">
                  <p className="font-medium text-gray-900 dark:text-white">{u.name}</p>
                  <p className="text-xs text-gray-400">{u.email}</p>
                </td>
                <td className="py-2.5 px-4 capitalize text-gray-500 dark:text-gray-400">{u.role}</td>
                <td className="py-2.5 px-4 text-right">
                  <button onClick={() => handleReset(u.email)} className="p-2 text-gray-400 hover:text-brand-600" title="Reset Kata Sandi">
                    <KeyRound size={16} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function SimpleListTab({ title, icon: Icon, collectionName, service, placeholder }) {
  const { data: items, loading } = useFirestoreCollection(collectionName, 'nama', 'asc');
  const [nama, setNama] = useState('');
  const [toDelete, setToDelete] = useState(null);

  const handleAdd = async (e) => {
    e.preventDefault();
    if (!nama.trim()) return;
    try {
      await service.create({ nama: nama.trim() });
      setNama('');
      toast.success(`${title} berhasil ditambahkan`);
    } catch {
      toast.error('Gagal menambahkan data');
    }
  };

  const handleDelete = async () => {
    try {
      await service.remove(toDelete.id);
      toast.success('Data berhasil dihapus');
    } catch {
      toast.error('Gagal menghapus data');
    } finally {
      setToDelete(null);
    }
  };

  return (
    <div className="card space-y-4">
      <h3 className="font-semibold text-gray-900 dark:text-white flex items-center gap-2"><Icon size={17} /> Kelola {title}</h3>
      <form onSubmit={handleAdd} className="flex gap-2">
        <input className="input-field flex-1" placeholder={placeholder} value={nama} onChange={(e) => setNama(e.target.value)} />
        <button type="submit" className="btn-primary">Tambah</button>
      </form>
      <div className="space-y-1.5">
        {!loading && items.length === 0 && <p className="text-sm text-gray-400 text-center py-4">Belum ada data {title.toLowerCase()}.</p>}
        {items.map((it) => (
          <div key={it.id} className="flex items-center justify-between px-3 py-2 rounded-xl bg-gray-50 dark:bg-gray-700/40">
            <span className="text-sm text-gray-700 dark:text-gray-200">{it.nama}</span>
            <button onClick={() => setToDelete(it)} className="text-gray-400 hover:text-red-600"><Trash2 size={15} /></button>
          </div>
        ))}
      </div>
      <ConfirmDialog open={!!toDelete} title={`Hapus ${title}`} message={`Yakin ingin menghapus "${toDelete?.nama}"?`} onConfirm={handleDelete} onCancel={() => setToDelete(null)} />
    </div>
  );
}

function BackupTab() {
  const fileRef = useRef(null);
  const [busy, setBusy] = useState(false);

  const handleBackup = async () => {
    setBusy(true);
    try {
      await backupAllData();
      toast.success('Backup berhasil diunduh');
    } catch {
      toast.error('Gagal membuat backup');
    } finally {
      setBusy(false);
    }
  };

  const handleRestore = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setBusy(true);
    try {
      const result = await restoreFromBackupFile(file);
      const total = Object.values(result).reduce((a, b) => a + b, 0);
      toast.success(`Restore selesai: ${total} dokumen dipulihkan`);
    } catch {
      toast.error('Gagal memulihkan data, pastikan format file benar');
    } finally {
      setBusy(false);
      e.target.value = '';
    }
  };

  return (
    <div className="grid md:grid-cols-2 gap-4">
      <div className="card space-y-3">
        <h3 className="font-semibold text-gray-900 dark:text-white flex items-center gap-2"><DownloadCloud size={17} /> Backup Database</h3>
        <p className="text-sm text-gray-500 dark:text-gray-400">Unduh seluruh data sistem (santri, hafalan, absensi, keuangan, dll) sebagai file JSON.</p>
        <button onClick={handleBackup} disabled={busy} className="btn-primary w-full">{busy ? 'Memproses...' : 'Unduh Backup'}</button>
      </div>
      <div className="card space-y-3">
        <h3 className="font-semibold text-gray-900 dark:text-white flex items-center gap-2"><UploadCloud size={17} /> Restore Database</h3>
        <p className="text-sm text-gray-500 dark:text-gray-400">Pulihkan data dari file backup JSON. Data akan ditambahkan sebagai dokumen baru.</p>
        <button onClick={() => fileRef.current?.click()} disabled={busy} className="btn-secondary w-full">{busy ? 'Memproses...' : 'Pilih File Backup'}</button>
        <input ref={fileRef} type="file" accept=".json" onChange={handleRestore} className="hidden" />
      </div>
    </div>
  );
}
