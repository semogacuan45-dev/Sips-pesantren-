import { useEffect, useMemo, useState } from 'react';
import toast from 'react-hot-toast';
import { CheckCircle2 } from 'lucide-react';
import { useFirestoreCollection } from '../hooks/useFirestoreCollection';
import { getAttendanceForDate, setAttendance, STATUS_OPTIONS } from '../services/attendanceService';
import { useAuth } from '../context/AuthContext.jsx';

const STATUS_LABEL = { hadir: 'Hadir', izin: 'Izin', sakit: 'Sakit', alpa: 'Alpa', terlambat: 'Terlambat' };
const STATUS_COLOR = {
  hadir: 'bg-green-600 text-white',
  izin: 'bg-blue-500 text-white',
  sakit: 'bg-amber-500 text-white',
  alpa: 'bg-red-500 text-white',
  terlambat: 'bg-orange-400 text-white'
};

export default function Attendance() {
  const { isAdmin, isMusyrif, profile } = useAuth();
  const canEdit = isAdmin || isMusyrif;
  const { data: students } = useFirestoreCollection('students', 'nama', 'asc');

  const [tanggal, setTanggal] = useState(new Date().toISOString().slice(0, 10));
  const [kelasFilter, setKelasFilter] = useState('');
  const [records, setRecords] = useState({}); // studentId -> record
  const [loading, setLoading] = useState(true);
  const [savingId, setSavingId] = useState(null);

  const kelasOptions = useMemo(() => [...new Set(students.map((s) => s.kelas).filter(Boolean))].sort(), [students]);

  useEffect(() => {
    let active = true;
    setLoading(true);
    getAttendanceForDate(tanggal).then((data) => {
      if (!active) return;
      const map = {};
      data.forEach((r) => { map[r.studentId] = r; });
      setRecords(map);
      setLoading(false);
    });
    return () => { active = false; };
  }, [tanggal]);

  const scopedStudents = useMemo(() => {
    let list = students;
    if (profile?.role === 'wali' && profile?.studentId) {
      list = list.filter((s) => s.id === profile.studentId);
    }
    if (kelasFilter) list = list.filter((s) => s.kelas === kelasFilter);
    return list;
  }, [students, kelasFilter, profile]);

  const handleMark = async (student, status) => {
    if (!canEdit) return;
    setSavingId(student.id);
    try {
      const existing = records[student.id];
      await setAttendance({ id: existing?.id, studentId: student.id, studentName: student.nama, tanggal, status });
      setRecords((r) => ({ ...r, [student.id]: { ...(existing || {}), studentId: student.id, studentName: student.nama, status } }));
    } catch {
      toast.error('Gagal menyimpan absensi');
    } finally {
      setSavingId(null);
    }
  };

  const summary = useMemo(() => {
    const s = { hadir: 0, izin: 0, sakit: 0, alpa: 0, terlambat: 0 };
    scopedStudents.forEach((st) => {
      const rec = records[st.id];
      if (rec?.status) s[rec.status] += 1;
    });
    return s;
  }, [scopedStudents, records]);

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-xl font-bold text-gray-900 dark:text-white">Absensi Santri</h2>
        <p className="text-sm text-gray-500 dark:text-gray-400">Catat kehadiran santri harian</p>
      </div>

      <div className="flex flex-col md:flex-row gap-3">
        <input type="date" value={tanggal} onChange={(e) => setTanggal(e.target.value)} className="input-field md:w-52" />
        {profile?.role !== 'wali' && (
          <select className="input-field md:w-52" value={kelasFilter} onChange={(e) => setKelasFilter(e.target.value)}>
            <option value="">Semua Kelas</option>
            {kelasOptions.map((k) => <option key={k} value={k}>{k}</option>)}
          </select>
        )}
      </div>

      <div className="grid grid-cols-5 gap-2">
        {STATUS_OPTIONS.map((st) => (
          <div key={st} className="card !p-3 text-center">
            <p className="text-lg font-bold text-gray-900 dark:text-white">{summary[st]}</p>
            <p className="text-[11px] text-gray-400 capitalize">{STATUS_LABEL[st]}</p>
          </div>
        ))}
      </div>

      <div className="space-y-2">
        {loading && <p className="text-center text-gray-400 py-8 text-sm">Memuat data absensi...</p>}
        {!loading && scopedStudents.length === 0 && <p className="text-center text-gray-400 py-8 text-sm">Tidak ada santri.</p>}
        {!loading && scopedStudents.map((s) => {
          const rec = records[s.id];
          return (
            <div key={s.id} className="card flex items-center gap-3 !p-3">
              <img
                src={s.foto || `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(s.nama || 'S')}`}
                alt={s.nama}
                className="w-10 h-10 rounded-full object-cover bg-gray-100 shrink-0"
              />
              <div className="flex-1 min-w-0">
                <p className="font-medium text-gray-900 dark:text-white text-sm truncate">{s.nama}</p>
                <p className="text-xs text-gray-400">{s.kelas}</p>
              </div>
              {rec?.status && !canEdit && (
                <span className={`text-xs px-2.5 py-1 rounded-full font-medium flex items-center gap-1 ${STATUS_COLOR[rec.status]}`}>
                  <CheckCircle2 size={12} /> {STATUS_LABEL[rec.status]}
                </span>
              )}
              {canEdit && (
                <div className="flex gap-1 flex-wrap justify-end">
                  {STATUS_OPTIONS.map((st) => (
                    <button
                      key={st}
                      disabled={savingId === s.id}
                      onClick={() => handleMark(s, st)}
                      className={`text-[11px] px-2 py-1.5 rounded-lg font-medium transition-colors ${
                        rec?.status === st ? STATUS_COLOR[st] : 'bg-gray-100 dark:bg-gray-700 text-gray-500 dark:text-gray-300'
                      }`}
                    >
                      {STATUS_LABEL[st]}
                    </button>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
