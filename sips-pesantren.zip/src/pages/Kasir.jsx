import { useEffect, useRef, useState } from 'react';
import { ScanLine, X, ShoppingBag, ArrowDownCircle, Search } from 'lucide-react';
import toast from 'react-hot-toast';
import { useFirestoreCollection } from '../hooks/useFirestoreCollection';
import { processWalletTransaction } from '../services/walletService';
import { formatRupiah } from '../utils/format.js';
import { useAuth } from '../context/AuthContext.jsx';

const QUICK_AMOUNTS = [2000, 5000, 10000, 20000, 50000];

export default function Kasir() {
  const { profile } = useAuth();
  const { data: students } = useFirestoreCollection('students', 'nama', 'asc');
  const { data: wallets } = useFirestoreCollection('wallets');

  const [scanning, setScanning] = useState(false);
  const [manualNis, setManualNis] = useState('');
  const [selected, setSelected] = useState(null);
  const [nominal, setNominal] = useState('');
  const [jenis, setJenis] = useState('jajan');
  const [processing, setProcessing] = useState(false);
  const scannerRef = useRef(null);
  const html5QrRef = useRef(null);

  const walletMap = Object.fromEntries(wallets.map((w) => [w.studentId || w.id, w]));

  useEffect(() => {
    if (!scanning) return;
    let stopped = false;

    import('html5-qrcode').then(({ Html5Qrcode }) => {
      if (stopped) return;
      const qr = new Html5Qrcode('kasir-qr-reader');
      html5QrRef.current = qr;
      qr.start(
        { facingMode: 'environment' },
        { fps: 10, qrbox: 220 },
        (decodedText) => {
          handleFoundCode(decodedText);
          stopScanner();
        },
        () => {}
      ).catch(() => {
        toast.error('Tidak bisa mengakses kamera. Coba cari manual dengan NIS.');
        setScanning(false);
      });
    });

    return () => {
      stopped = true;
      stopScanner();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [scanning]);

  const stopScanner = () => {
    if (html5QrRef.current) {
      html5QrRef.current.stop().then(() => html5QrRef.current.clear()).catch(() => {});
      html5QrRef.current = null;
    }
  };

  const handleFoundCode = (code) => {
    const student = students.find((s) => s.nis === code || s.id === code);
    if (!student) {
      toast.error(`Santri dengan kode "${code}" tidak ditemukan`);
      return;
    }
    setSelected(student);
    setScanning(false);
    toast.success(`Santri ditemukan: ${student.nama}`);
  };

  const handleManualSearch = () => {
    if (!manualNis.trim()) return;
    handleFoundCode(manualNis.trim());
  };

  const handleConfirm = async () => {
    const nominalNum = Number(nominal);
    if (!selected) return;
    if (!nominalNum || nominalNum <= 0) {
      toast.error('Masukkan nominal yang valid');
      return;
    }
    setProcessing(true);
    try {
      await processWalletTransaction({
        studentId: selected.id,
        studentName: selected.nama,
        jenis,
        nominal: nominalNum,
        catatan: jenis === 'jajan' ? 'Transaksi jajan via Kasir' : 'Top up via Kasir',
        createdBy: profile?.name
      });
      toast.success(`Transaksi berhasil: ${selected.nama} — ${formatRupiah(nominalNum)}`);
      setSelected(null);
      setNominal('');
      setManualNis('');
    } catch (err) {
      toast.error(err.message === 'Saldo tidak mencukupi' ? 'Saldo santri tidak mencukupi' : 'Transaksi gagal diproses');
    } finally {
      setProcessing(false);
    }
  };

  const saldo = selected ? (walletMap[selected.id]?.saldo || 0) : 0;

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-xl font-bold text-gray-900 dark:text-white">Kasir Jajan</h2>
        <p className="text-sm text-gray-500 dark:text-gray-400">Scan QR santri untuk transaksi jajan/top up secara cepat</p>
      </div>

      {!selected && (
        <div className="card space-y-4">
          {!scanning ? (
            <button onClick={() => setScanning(true)} className="btn-primary w-full flex items-center justify-center gap-2">
              <ScanLine size={18} /> Mulai Scan QR Santri
            </button>
          ) : (
            <div className="space-y-3">
              <div id="kasir-qr-reader" ref={scannerRef} className="rounded-xl overflow-hidden bg-black" />
              <button onClick={() => setScanning(false)} className="btn-secondary w-full flex items-center justify-center gap-2">
                <X size={16} /> Batalkan Scan
              </button>
            </div>
          )}

          <div className="flex items-center gap-2">
            <div className="h-px bg-gray-100 dark:bg-gray-700 flex-1" />
            <span className="text-xs text-gray-400">atau cari manual</span>
            <div className="h-px bg-gray-100 dark:bg-gray-700 flex-1" />
          </div>

          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
              <input
                value={manualNis}
                onChange={(e) => setManualNis(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleManualSearch()}
                placeholder="Ketik NIS santri..."
                className="input-field pl-9"
              />
            </div>
            <button onClick={handleManualSearch} className="btn-secondary">Cari</button>
          </div>
        </div>
      )}

      {selected && (
        <div className="card space-y-4 animate-slide-up">
          <div className="flex items-center gap-3">
            <img
              src={selected.foto || `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(selected.nama || 'S')}`}
              alt={selected.nama}
              className="w-14 h-14 rounded-full object-cover bg-gray-100"
            />
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-gray-900 dark:text-white">{selected.nama}</p>
              <p className="text-xs text-gray-400">{selected.kelas} • NIS {selected.nis}</p>
            </div>
            <button onClick={() => setSelected(null)} className="text-gray-400 hover:text-gray-600"><X size={18} /></button>
          </div>

          <div className="rounded-xl bg-brand-50 dark:bg-brand-900/20 p-3 text-center">
            <p className="text-xs text-gray-500 dark:text-gray-400">Saldo Saat Ini</p>
            <p className="text-2xl font-bold text-brand-600">{formatRupiah(saldo)}</p>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => setJenis('jajan')}
              className={`flex items-center justify-center gap-1.5 py-2.5 rounded-xl text-sm font-medium border-2 ${jenis === 'jajan' ? 'border-amber-500 bg-amber-50 text-amber-600 dark:bg-amber-900/20' : 'border-gray-200 dark:border-gray-700 text-gray-500'}`}
            >
              <ShoppingBag size={15} /> Jajan (Potong)
            </button>
            <button
              onClick={() => setJenis('masuk')}
              className={`flex items-center justify-center gap-1.5 py-2.5 rounded-xl text-sm font-medium border-2 ${jenis === 'masuk' ? 'border-green-500 bg-green-50 text-green-600 dark:bg-green-900/20' : 'border-gray-200 dark:border-gray-700 text-gray-500'}`}
            >
              <ArrowDownCircle size={15} /> Top Up (Tambah)
            </button>
          </div>

          <div>
            <label className="label-field">Nominal (Rp)</label>
            <input type="number" min="0" className="input-field text-lg font-semibold" value={nominal} onChange={(e) => setNominal(e.target.value)} placeholder="0" />
            <div className="flex flex-wrap gap-1.5 mt-2">
              {QUICK_AMOUNTS.map((amt) => (
                <button key={amt} onClick={() => setNominal(String(amt))} className="text-xs px-3 py-1.5 rounded-lg bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300">
                  {formatRupiah(amt)}
                </button>
              ))}
            </div>
          </div>

          <button onClick={handleConfirm} disabled={processing} className="btn-primary w-full">
            {processing ? 'Memproses...' : `Konfirmasi ${jenis === 'jajan' ? 'Potong Saldo' : 'Top Up'}`}
          </button>
        </div>
      )}
    </div>
  );
}
