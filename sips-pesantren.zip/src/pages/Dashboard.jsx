import { Users, BookOpen, CalendarCheck, Wallet, Receipt, Trophy } from 'lucide-react';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import StatCard from '../components/StatCard.jsx';
import { CardSkeleton } from '../components/Skeleton.jsx';
import { useDashboardStats } from '../hooks/useDashboardStats.js';
import { useAuth } from '../context/AuthContext.jsx';
import { formatRupiah } from '../utils/format.js';

export default function Dashboard() {
  const { profile, role } = useAuth();
  const stats = useDashboardStats();

  const cards = [
    { icon: Users, label: 'Jumlah Santri', value: stats.totalSantri, color: 'brand', roles: ['admin', 'musyrif', 'bendahara'] },
    { icon: BookOpen, label: 'Hafalan Hari Ini', value: stats.hafalanHariIni, color: 'blue', roles: ['admin', 'musyrif', 'wali'] },
    { icon: CalendarCheck, label: 'Absensi Hari Ini', value: stats.hadirHariIni, color: 'brand', roles: ['admin', 'musyrif', 'wali'] },
    { icon: Wallet, label: 'Total Saldo Uang Jajan', value: formatRupiah(stats.totalSaldo), color: 'amber', roles: ['admin', 'bendahara'] },
    { icon: Receipt, label: 'Transaksi Hari Ini', value: stats.transaksiHariIni, color: 'rose', roles: ['admin', 'bendahara'] }
  ].filter((c) => c.roles.includes(role));

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold text-gray-900 dark:text-white">
          Assalamu&apos;alaikum, {profile?.name?.split(' ')[0] || 'Pengguna'} 👋
        </h2>
        <p className="text-sm text-gray-500 dark:text-gray-400">Berikut ringkasan aktivitas pesantren hari ini.</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4">
        {stats.loading
          ? Array.from({ length: 4 }).map((_, i) => <CardSkeleton key={i} />)
          : cards.map((c) => <StatCard key={c.label} {...c} />)}
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <div className="card">
          <h3 className="font-semibold text-gray-900 dark:text-white mb-4">Grafik Hafalan (7 Hari Terakhir)</h3>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={stats.trenHafalan}>
              <CartesianGrid strokeDasharray="3 3" stroke="currentColor" className="text-gray-100 dark:text-gray-700" />
              <XAxis dataKey="tanggal" tick={{ fontSize: 12 }} stroke="#9ca3af" />
              <YAxis tick={{ fontSize: 12 }} stroke="#9ca3af" allowDecimals={false} />
              <Tooltip contentStyle={{ borderRadius: 12, fontSize: 12, border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }} />
              <Line type="monotone" dataKey="jumlah" stroke="#059669" strokeWidth={2.5} dot={{ r: 3 }} name="Setoran Hafalan" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="card">
          <h3 className="font-semibold text-gray-900 dark:text-white mb-4">Grafik Absensi (7 Hari Terakhir)</h3>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={stats.trenAbsensi}>
              <CartesianGrid strokeDasharray="3 3" stroke="currentColor" className="text-gray-100 dark:text-gray-700" />
              <XAxis dataKey="tanggal" tick={{ fontSize: 12 }} stroke="#9ca3af" />
              <YAxis tick={{ fontSize: 12 }} stroke="#9ca3af" allowDecimals={false} />
              <Tooltip contentStyle={{ borderRadius: 12, fontSize: 12, border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }} />
              <Bar dataKey="jumlah" fill="#34d399" radius={[6, 6, 0, 0]} name="Hadir" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="card">
        <div className="flex items-center gap-2 mb-4">
          <Trophy size={18} className="text-amber-500" />
          <h3 className="font-semibold text-gray-900 dark:text-white">Santri Terbaik (Hafalan Terbanyak)</h3>
        </div>
        <div className="space-y-2">
          {stats.santriTerbaik.length === 0 && !stats.loading && (
            <p className="text-sm text-gray-400 text-center py-4">Belum ada data hafalan santri.</p>
          )}
          {stats.santriTerbaik.map((s, idx) => (
            <div key={s.id} className="flex items-center gap-3 py-2 border-b border-gray-50 dark:border-gray-700 last:border-0">
              <span className="w-6 h-6 flex items-center justify-center rounded-full bg-brand-50 dark:bg-brand-900/30 text-brand-700 dark:text-brand-400 text-xs font-bold">
                {idx + 1}
              </span>
              <img
                src={s.foto || `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(s.nama || 'S')}`}
                alt={s.nama}
                className="w-8 h-8 rounded-full object-cover bg-gray-100"
              />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900 dark:text-white truncate">{s.nama}</p>
                <p className="text-xs text-gray-400">Kelas {s.kelas || '-'}</p>
              </div>
              <span className="text-sm font-semibold text-brand-600">{s.totalHafalanJuz || 0} Juz</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
