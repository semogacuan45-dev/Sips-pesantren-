import { useMemo, useState } from 'react';
import { Plus, Search, Pencil, Trash2, BookOpen } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import toast from 'react-hot-toast';
import { useFirestoreCollection } from '../hooks/useFirestoreCollection';
import { deleteTahfidzEntry } from '../services/tahfidzService';
import TahfidzFormModal from '../components/TahfidzFormModal.jsx';
import ConfirmDialog from '../components/ConfirmDialog.jsx';
import { TableRowSkeleton } from '../components/Skeleton.jsx';
import { formatTanggalSingkat } from '../utils/format.js';
import { useAuth } from '../context/AuthContext.jsx';

export default function Tahfidz() {
  const { isAdmin, isMusyrif, profile } = useAuth();
  const canEdit = isAdmin || isMusyrif;
  const { data: students } = useFirestoreCollection('students', 'nama', 'asc');
  const { data: entries, loading } = useFirestoreCollection('tahfidz', 'tanggal', 'desc');

  const [search, setSearch] = useState('');
  const [selectedStudent, setSelectedStudent] = useState('');
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [toDelete, setToDelete] = useState(null);

  // Wali santri hanya melihat data anaknya (bila terhubung lewat studentId di profil)
  const scopedEntries = useMemo(() => {
    if (profile?.role === 'wali' && profile?.studentId) {
      return entries.filter((e) => e.studentId === profile.studentId);
    }
    return entries;
  }, [entries, profile]);

  const filtered = useMemo(() => {
    return scopedEntries.filter((e) => {
      const matchSearch = !search || e.studentName?.toLowerCase().includes(search.toLowerCase()) || e.surat?.toLowerCase().includes(search.toLowerCase());
      const matchStudent = !selectedStudent || e.studentId === selectedStudent;
      return matchSearch && matchStudent;
    });
  }, [scopedEntries, search, selectedStudent]);

  const chartData = useMemo(() => {
    return [...filtered].reverse().slice(-14).map((e) => ({
      tanggal: formatTanggalSingkat(e.tanggal),
      nilai: e.nilai
    }));
  }, [filtered]);

  const handleDelete = async () => {
    if (!toDelete) return;
    try {
      await deleteTahfidzEntry(toDelete.id);
      toast.success('Catatan hafalan berhasil dihapus');
    } catch {
      toast.error('Gagal menghapus catatan');
    } finally {
      setToDelete(null);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-gray-900 dark:text-white">Hafalan Tahfidz</h2>
          <p className="text-sm text-gray-500 dark:text-gray-400">{filtered.length} catatan hafalan</p>
        </div>
        {canEdit && (
          <button onClick={() => { setEditing(null); setFormOpen(true); }} className="btn-primary text-sm flex items-center gap-1.5 self-start">
            <Plus size={15} /> Input Hafalan
          </button>
        )}
      </div>

      <div className="card">
        <div className="flex items-center gap-2 mb-4">
          <BookOpen size={18} className="text-brand-600" />
          <h3 className="font-semibold text-gray-900 dark:text-white">Grafik Perkembangan Nilai</h3>
        </div>
        <ResponsiveContainer width="100%" height={200}>
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" className="text-gray-100 dark:text-gray-700" />
            <XAxis dataKey="tanggal" tick={{ fontSize: 11 }} stroke="#9ca3af" />
            <YAxis domain={[0, 100]} tick={{ fontSize: 11 }} stroke="#9ca3af" />
            <Tooltip contentStyle={{ borderRadius: 12, fontSize: 12, border: 'none' }} />
            <Line type="monotone" dataKey="nilai" stroke="#059669" strokeWidth={2.5} dot={{ r: 3 }} />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="flex flex-col md:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Cari nama santri atau surat..." className="input-field pl-9" />
        </div>
        {profile?.role !== 'wali' && (
          <select className="input-field md:w-56" value={selectedStudent} onChange={(e) => setSelectedStudent(e.target.value)}>
            <option value="">Semua Santri</option>
            {students.map((s) => <option key={s.id} value={s.id}>{s.nama}</option>)}
          </select>
        )}
      </div>

      <div className="card !p-0 overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-gray-400 border-b border-gray-100 dark:border-gray-700">
              <th className="py-3 px-4 font-medium">Tanggal</th>
              <th className="py-3 px-4 font-medium">Santri</th>
              <th className="py-3 px-4 font-medium">Surat / Ayat</th>
              <th className="py-3 px-4 font-medium">Nilai</th>
              <th className="py-3 px-4 font-medium">Kelancaran</th>
              {canEdit && <th className="py-3 px-4 font-medium text-right">Aksi</th>}
            </tr>
          </thead>
          <tbody>
            {loading && Array.from({ length: 5 }).map((_, i) => <TableRowSkeleton key={i} cols={6} />)}
            {!loading && filtered.length === 0 && (
              <tr><td colSpan={6} className="text-center py-10 text-gray-400">Belum ada catatan hafalan.</td></tr>
            )}
            {!loading && filtered.slice(0, 50).map((e) => (
              <tr key={e.id} className="border-b border-gray-50 dark:border-gray-700/50">
                <td className="py-2.5 px-4 text-gray-500 dark:text-gray-400 whitespace-nowrap">{formatTanggalSingkat(e.tanggal)}</td>
                <td className="py-2.5 px-4 font-medium text-gray-900 dark:text-white">{e.studentName}</td>
                <td className="py-2.5 px-4 text-gray-500 dark:text-gray-400">{e.surat} : {e.ayat}</td>
                <td className="py-2.5 px-4">
                  <span className={`font-semibold ${e.nilai >= 80 ? 'text-green-600' : e.nilai >= 60 ? 'text-amber-600' : 'text-red-500'}`}>{e.nilai}</span>
                </td>
                <td className="py-2.5 px-4 text-gray-500 dark:text-gray-400">{e.kelancaran}</td>
                {canEdit && (
                  <td className="py-2.5 px-4">
                    <div className="flex items-center justify-end gap-1">
                      <button onClick={() => { setEditing(e); setFormOpen(true); }} className="p-2 text-gray-400 hover:text-brand-600"><Pencil size={16} /></button>
                      <button onClick={() => setToDelete(e)} className="p-2 text-gray-400 hover:text-red-600"><Trash2 size={16} /></button>
                    </div>
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <TahfidzFormModal open={formOpen} onClose={() => setFormOpen(false)} entry={editing} students={students} />
      <ConfirmDialog
        open={!!toDelete}
        title="Hapus Catatan Hafalan"
        message="Yakin ingin menghapus catatan hafalan ini?"
        onConfirm={handleDelete}
        onCancel={() => setToDelete(null)}
      />
    </div>
  );
}
