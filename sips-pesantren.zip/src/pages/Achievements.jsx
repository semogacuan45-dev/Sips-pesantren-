import { useState } from 'react';
import { Plus, Pencil, Trash2, Award, Wallet } from 'lucide-react';
import toast from 'react-hot-toast';
import { useFirestoreCollection } from '../hooks/useFirestoreCollection';
import { createRecordService } from '../services/recordService';
import { processWalletTransaction } from '../services/walletService';
import SimpleRecordFormModal from '../components/SimpleRecordFormModal.jsx';
import ConfirmDialog from '../components/ConfirmDialog.jsx';
import { formatTanggalSingkat, formatRupiah } from '../utils/format.js';
import { useAuth } from '../context/AuthContext.jsx';

const service = createRecordService('achievements');

const FIELDS = [
  { key: 'tanggal', label: 'Tanggal', type: 'date', required: true, default: new Date().toISOString().slice(0, 10) },
  { key: 'jenis', label: 'Jenis Prestasi', type: 'text', required: true },
  { key: 'hadiah', label: 'Hadiah (Rp) — isi untuk tambah saldo otomatis, kosongkan/0 jika tidak ada', type: 'number', default: 0 },
  { key: 'catatan', label: 'Catatan / Keterangan', type: 'textarea' },
  { key: 'foto', label: 'Foto / Sertifikat', type: 'photo' }
];

export default function Achievements() {
  const { isAdmin, isMusyrif, profile } = useAuth();
  const canEdit = isAdmin || isMusyrif;
  const { data: students } = useFirestoreCollection('students', 'nama', 'asc');
  const { data: entries, loading } = useFirestoreCollection('achievements', 'tanggal', 'desc');
  const scoped = profile?.role === 'wali' && profile?.studentId ? entries.filter((e) => e.studentId === profile.studentId) : entries;

  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [toDelete, setToDelete] = useState(null);

  const handleDelete = async () => {
    try {
      await service.remove(toDelete.id);
      toast.success('Data prestasi berhasil dihapus');
    } catch {
      toast.error('Gagal menghapus data');
    } finally {
      setToDelete(null);
    }
  };

  // Integrasi: jika hadiah diisi, otomatis tambah saldo uang jajan santri terkait.
  const handleAfterSave = async (payload) => {
    const nominal = Number(payload.hadiah) || 0;
    if (nominal <= 0) return;
    try {
      await processWalletTransaction({
        studentId: payload.studentId,
        studentName: payload.studentName,
        jenis: 'masuk',
        nominal,
        catatan: `Hadiah prestasi: ${payload.jenis}`,
        createdBy: profile?.name
      });
      toast.success(`Saldo ${payload.studentName} otomatis ditambah ${formatRupiah(nominal)}`);
    } catch {
      toast.error('Gagal menambah saldo otomatis');
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-gray-900 dark:text-white">Prestasi Santri</h2>
          <p className="text-sm text-gray-500 dark:text-gray-400">{scoped.length} pencapaian tercatat</p>
        </div>
        {canEdit && (
          <button onClick={() => { setEditing(null); setFormOpen(true); }} className="btn-primary text-sm flex items-center gap-1.5 self-start">
            <Plus size={15} /> Tambah Prestasi
          </button>
        )}
      </div>

      {canEdit && (
        <div className="card !p-3 bg-green-50/60 dark:bg-green-900/10 border-green-100 dark:border-green-900/30 flex items-start gap-2">
          <Wallet size={16} className="text-green-600 mt-0.5 shrink-0" />
          <p className="text-xs text-gray-600 dark:text-gray-300">
            Isi kolom "Hadiah" saat menambah prestasi untuk menambah saldo Uang Jajan santri secara otomatis sebagai bentuk apresiasi.
          </p>
        </div>
      )}

      <div className="grid md:grid-cols-2 gap-3">
        {!loading && scoped.length === 0 && (
          <div className="card text-center py-10 text-gray-400 md:col-span-2"><Award className="mx-auto mb-2 text-gray-300" size={28} />Belum ada data prestasi.</div>
        )}
        {scoped.map((e) => (
          <div key={e.id} className="card flex items-start gap-3">
            <div className="w-11 h-11 rounded-xl bg-amber-50 dark:bg-amber-900/30 flex items-center justify-center shrink-0">
              <Award className="text-amber-500" size={20} />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <p className="font-medium text-gray-900 dark:text-white text-sm">{e.jenis}</p>
                {Number(e.hadiah) > 0 && (
                  <span className="text-xs px-2 py-0.5 rounded-full font-medium bg-green-50 text-green-600 dark:bg-green-900/20">+{formatRupiah(e.hadiah)}</span>
                )}
              </div>
              <p className="text-xs text-gray-400 mb-1">{e.studentName} • {formatTanggalSingkat(e.tanggal)}</p>
              {e.catatan && <p className="text-sm text-gray-500 dark:text-gray-400">{e.catatan}</p>}
              {e.foto && <img src={e.foto} alt="sertifikat" className="mt-2 w-full max-w-[200px] rounded-lg object-cover" />}
            </div>
            {canEdit && (
              <div className="flex gap-1 shrink-0">
                <button onClick={() => { setEditing(e); setFormOpen(true); }} className="p-2 text-gray-400 hover:text-brand-600"><Pencil size={16} /></button>
                <button onClick={() => setToDelete(e)} className="p-2 text-gray-400 hover:text-red-600"><Trash2 size={16} /></button>
              </div>
            )}
          </div>
        ))}
      </div>

      <SimpleRecordFormModal
        open={formOpen} onClose={() => setFormOpen(false)} title={editing ? 'Edit Prestasi' : 'Tambah Prestasi'}
        fields={FIELDS} students={students} service={service} entry={editing} photoFolder="achievements"
        onAfterSave={handleAfterSave}
      />
      <ConfirmDialog open={!!toDelete} title="Hapus Data Prestasi" message="Yakin ingin menghapus catatan ini?" onConfirm={handleDelete} onCancel={() => setToDelete(null)} />
    </div>
  );
}
