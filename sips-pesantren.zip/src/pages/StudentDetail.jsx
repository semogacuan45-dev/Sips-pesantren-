import { useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, BookOpen, CalendarCheck, Wallet, AlertTriangle, Award, Phone, MapPin } from 'lucide-react';
import { useFirestoreCollection } from '../hooks/useFirestoreCollection';
import { formatRupiah, formatTanggalSingkat, formatTanggal } from '../utils/format.js';

function StatBlock({ icon: Icon, label, value, color }) {
  return (
    <div className="card !p-3 text-center">
      <div className={`w-9 h-9 mx-auto rounded-xl flex items-center justify-center mb-1.5 ${color}`}>
        <Icon size={16} />
      </div>
      <p className="text-lg font-bold text-gray-900 dark:text-white leading-tight">{value}</p>
      <p className="text-[11px] text-gray-400">{label}</p>
    </div>
  );
}

export default function StudentDetail() {
  const { id } = useParams();
  const navigate = useNavigate();

  const { data: students, loading: loadingStudents } = useFirestoreCollection('students');
  const { data: tahfidz } = useFirestoreCollection('tahfidz', 'tanggal', 'desc');
  const { data: attendance } = useFirestoreCollection('attendance', 'tanggal', 'desc');
  const { data: wallets } = useFirestoreCollection('wallets');
  const { data: violations } = useFirestoreCollection('violations', 'tanggal', 'desc');
  const { data: achievements } = useFirestoreCollection('achievements', 'tanggal', 'desc');

  const student = students.find((s) => s.id === id);
  const wallet = wallets.find((w) => (w.studentId || w.id) === id);
  const myTahfidz = useMemo(() => tahfidz.filter((t) => t.studentId === id), [tahfidz, id]);
  const myAttendance = useMemo(() => attendance.filter((a) => a.studentId === id), [attendance, id]);
  const myViolations = useMemo(() => violations.filter((v) => v.studentId === id), [violations, id]);
  const myAchievements = useMemo(() => achievements.filter((a) => a.studentId === id), [achievements, id]);

  const hadirCount = myAttendance.filter((a) => a.status === 'hadir').length;
  const attendanceRate = myAttendance.length > 0 ? Math.round((hadirCount / myAttendance.length) * 100) : 0;
  const avgNilai = myTahfidz.length > 0 ? Math.round(myTahfidz.reduce((sum, t) => sum + (Number(t.nilai) || 0), 0) / myTahfidz.length) : 0;
  const totalDenda = myViolations.reduce((sum, v) => sum + (Number(v.denda) || 0), 0);
  const totalHadiah = myAchievements.reduce((sum, a) => sum + (Number(a.hadiah) || 0), 0);

  if (loadingStudents) {
    return <p className="text-center text-gray-400 py-10 text-sm">Memuat data santri...</p>;
  }

  if (!student) {
    return (
      <div className="text-center py-16">
        <p className="text-gray-400 mb-3">Santri tidak ditemukan.</p>
        <button onClick={() => navigate('/santri')} className="btn-secondary">Kembali ke Data Santri</button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <button onClick={() => navigate('/santri')} className="flex items-center gap-1.5 text-sm text-gray-500 dark:text-gray-400">
        <ArrowLeft size={16} /> Kembali ke Data Santri
      </button>

      <div className="card flex items-center gap-4 !p-4">
        <img
          src={student.foto || `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(student.nama || 'S')}`}
          alt={student.nama}
          className="w-16 h-16 rounded-2xl object-cover bg-gray-100"
        />
        <div className="flex-1 min-w-0">
          <h2 className="text-lg font-bold text-gray-900 dark:text-white truncate">{student.nama}</h2>
          <p className="text-sm text-gray-400">NIS {student.nis} • Kelas {student.kelas} • {student.kamar}</p>
          <div className="flex flex-wrap gap-3 mt-1.5 text-xs text-gray-500 dark:text-gray-400">
            {student.noHpWali && <span className="flex items-center gap-1"><Phone size={12} /> {student.noHpWali}</span>}
            {student.alamat && <span className="flex items-center gap-1 truncate max-w-[200px]"><MapPin size={12} /> {student.alamat}</span>}
          </div>
        </div>
        <span className={`text-xs px-2.5 py-1 rounded-full font-medium shrink-0 ${student.status === 'aktif' ? 'bg-green-50 text-green-600 dark:bg-green-900/30' : 'bg-gray-100 text-gray-500 dark:bg-gray-700'}`}>
          {student.status}
        </span>
      </div>

      <div className="grid grid-cols-3 md:grid-cols-5 gap-2">
        <StatBlock icon={BookOpen} label="Rata-rata Hafalan" value={avgNilai || '-'} color="bg-blue-50 dark:bg-blue-900/20 text-blue-600" />
        <StatBlock icon={CalendarCheck} label="Tingkat Hadir" value={`${attendanceRate}%`} color="bg-brand-50 dark:bg-brand-900/20 text-brand-600" />
        <StatBlock icon={Wallet} label="Saldo Jajan" value={formatRupiah(wallet?.saldo || 0)} color="bg-amber-50 dark:bg-amber-900/20 text-amber-600" />
        <StatBlock icon={AlertTriangle} label="Total Denda" value={formatRupiah(totalDenda)} color="bg-red-50 dark:bg-red-900/20 text-red-600" />
        <StatBlock icon={Award} label="Total Hadiah" value={formatRupiah(totalHadiah)} color="bg-purple-50 dark:bg-purple-900/20 text-purple-600" />
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="card">
          <h3 className="font-semibold text-gray-900 dark:text-white mb-3 flex items-center gap-2"><BookOpen size={16} className="text-blue-600" /> Riwayat Hafalan Terakhir</h3>
          <div className="space-y-2">
            {myTahfidz.length === 0 && <p className="text-sm text-gray-400 text-center py-4">Belum ada catatan hafalan.</p>}
            {myTahfidz.slice(0, 5).map((t) => (
              <div key={t.id} className="flex items-center justify-between text-sm border-b border-gray-50 dark:border-gray-700/50 pb-2 last:border-0">
                <div>
                  <p className="text-gray-700 dark:text-gray-200">{t.surat} : {t.ayat}</p>
                  <p className="text-xs text-gray-400">{formatTanggalSingkat(t.tanggal)}</p>
                </div>
                <span className={`font-semibold ${t.nilai >= 80 ? 'text-green-600' : t.nilai >= 60 ? 'text-amber-600' : 'text-red-500'}`}>{t.nilai}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="card">
          <h3 className="font-semibold text-gray-900 dark:text-white mb-3 flex items-center gap-2"><AlertTriangle size={16} className="text-red-500" /> Pelanggaran & Prestasi</h3>
          <div className="space-y-2">
            {myViolations.length === 0 && myAchievements.length === 0 && (
              <p className="text-sm text-gray-400 text-center py-4">Belum ada catatan pelanggaran/prestasi.</p>
            )}
            {myViolations.slice(0, 3).map((v) => (
              <div key={v.id} className="flex items-center justify-between text-sm border-b border-gray-50 dark:border-gray-700/50 pb-2 last:border-0">
                <div>
                  <p className="text-gray-700 dark:text-gray-200">{v.kategori} — {v.catatan?.slice(0, 40)}</p>
                  <p className="text-xs text-gray-400">{formatTanggalSingkat(v.tanggal)}</p>
                </div>
                {Number(v.denda) > 0 && <span className="text-xs font-semibold text-red-500">-{formatRupiah(v.denda)}</span>}
              </div>
            ))}
            {myAchievements.slice(0, 3).map((a) => (
              <div key={a.id} className="flex items-center justify-between text-sm border-b border-gray-50 dark:border-gray-700/50 pb-2 last:border-0">
                <div>
                  <p className="text-gray-700 dark:text-gray-200">🏆 {a.jenis}</p>
                  <p className="text-xs text-gray-400">{formatTanggalSingkat(a.tanggal)}</p>
                </div>
                {Number(a.hadiah) > 0 && <span className="text-xs font-semibold text-green-600">+{formatRupiah(a.hadiah)}</span>}
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="card">
        <h3 className="font-semibold text-gray-900 dark:text-white mb-2">Informasi Lengkap</h3>
        <div className="grid grid-cols-2 gap-3 text-sm">
          <div><p className="text-xs text-gray-400">Tempat, Tanggal Lahir</p><p className="text-gray-700 dark:text-gray-200">{student.tempatLahir}, {student.tanggalLahir ? formatTanggal(student.tanggalLahir) : '-'}</p></div>
          <div><p className="text-xs text-gray-400">Jenis Kelamin</p><p className="text-gray-700 dark:text-gray-200">{student.jenisKelamin === 'L' ? 'Laki-laki' : 'Perempuan'}</p></div>
          <div><p className="text-xs text-gray-400">Nama Ayah</p><p className="text-gray-700 dark:text-gray-200">{student.namaAyah || '-'}</p></div>
          <div><p className="text-xs text-gray-400">Nama Ibu</p><p className="text-gray-700 dark:text-gray-200">{student.namaIbu || '-'}</p></div>
          <div><p className="text-xs text-gray-400">Tanggal Masuk</p><p className="text-gray-700 dark:text-gray-200">{student.tanggalMasuk ? formatTanggal(student.tanggalMasuk) : '-'}</p></div>
        </div>
      </div>
    </div>
  );
}
