import { NavLink } from 'react-router-dom';
import { GraduationCap, LogOut, HardDrive, Cloud } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import { useDataMode } from '../context/DataModeContext.jsx';
import { NAV_ITEMS } from '../utils/navConfig.js';

export default function Sidebar() {
  const { role, profile, logout } = useAuth();
  const { mode } = useDataMode();
  const items = NAV_ITEMS.filter((item) => item.roles.includes(role));

  return (
    <aside className="hidden md:flex flex-col w-64 shrink-0 h-screen sticky top-0 bg-white dark:bg-gray-800 border-r border-gray-100 dark:border-gray-700">
      <div className="flex items-center gap-2 px-5 h-16 border-b border-gray-100 dark:border-gray-700">
        <div className="w-9 h-9 rounded-xl bg-brand-600 flex items-center justify-center">
          <GraduationCap className="text-white" size={20} />
        </div>
        <div>
          <p className="font-bold text-gray-900 dark:text-white leading-none">SIPS</p>
          <p className="text-[11px] text-gray-400">Pesantren Tahfidz</p>
        </div>
      </div>

      <div className="px-5 py-2">
        <span className={`inline-flex items-center gap-1.5 text-[11px] font-medium px-2.5 py-1 rounded-full ${
          mode === 'local' ? 'bg-amber-50 text-amber-600 dark:bg-amber-900/20' : 'bg-brand-50 text-brand-600 dark:bg-brand-900/20'
        }`}>
          {mode === 'local' ? <HardDrive size={11} /> : <Cloud size={11} />}
          Mode {mode === 'local' ? 'Lokal' : 'Cloud'}
        </span>
      </div>

      <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-1">
        {items.map(({ to, label, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            end={to === '/'}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors ${
                isActive
                  ? 'bg-brand-50 text-brand-700 dark:bg-brand-900/30 dark:text-brand-400'
                  : 'text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700/50'
              }`
            }
          >
            <Icon size={18} />
            {label}
          </NavLink>
        ))}
      </nav>

      <div className="p-3 border-t border-gray-100 dark:border-gray-700">
        <div className="flex items-center gap-3 px-2 py-2 mb-1">
          <div className="w-9 h-9 rounded-full bg-brand-100 dark:bg-brand-900/40 flex items-center justify-center text-brand-700 dark:text-brand-400 font-semibold text-sm">
            {(profile?.name || '?').charAt(0).toUpperCase()}
          </div>
          <div className="min-w-0">
            <p className="text-sm font-medium text-gray-900 dark:text-white truncate">{profile?.name || 'Pengguna'}</p>
            <p className="text-xs text-gray-400 capitalize">{role}</p>
          </div>
        </div>
        <button
          onClick={logout}
          className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-sm text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20"
        >
          <LogOut size={16} /> Keluar
        </button>
      </div>
    </aside>
  );
}
