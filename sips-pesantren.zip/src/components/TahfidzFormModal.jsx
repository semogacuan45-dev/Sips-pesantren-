import { useEffect, useState } from 'react';
import { X } from 'lucide-react';
import toast from 'react-hot-toast';
import { createTahfidzEntry, updateTahfidzEntry, KELANCARAN_OPTIONS, NILAI_TAJWID_OPTIONS } from '../services/tahfidzService';

const emptyForm = {
  studentId: '', studentName: '', tanggal: new Date().toISOString().slice(0, 10),
  surat: '', ayat: '', halaman: '', ziyadah: '', murajaah: '',
  nilai: '', kelancaran: 'Lancar', makharij: 'Baik', tajwid: 'Baik', catatan: ''
};

export default function TahfidzFormModal({ open, onClose, entry, students }) {
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (entry) {
      setForm({
        ...emptyForm,
        ...entry,
        tanggal: entry.tanggal?.toDate ? entry.tanggal.toDate().toISOString().slice(0, 10) : emptyForm.tanggal
      });
    } else {
      setForm(emptyForm);
    }
  }, [entry, open]);

  if (!open) return null;
  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));

  const handleStudentChange = (e) => {
    const id = e.target.value;
    const s = students.find((x) => x.id === id);
    setForm((f) => ({ ...f, studentId: id, studentName: s?.nama || '' }));
  };

  const validate = () => {
    const e = {};
    if (!form.studentId) e.studentId = 'Pilih santri terlebih dahulu';
    if (!form.surat.trim()) e.surat = 'Surat wajib diisi';
    if (!form.nilai || isNaN(Number(form.nilai)) || Number(form.nilai) < 0 || Number(form.nilai) > 100) {
      e.nilai = 'Nilai harus angka 0-100';
    }
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async (ev) => {
    ev.preventDefault();
    if (!validate()) return;
    setSaving(true);
    try {
      const payload = { ...form, nilai: Number(form.nilai) };
      if (entry?.id) {
        await updateTahfidzEntry(entry.id, payload);
        toast.success('Catatan hafalan berhasil diperbarui');
      } else {
        await createTahfidzEntry(payload);
        toast.success('Catatan hafalan berhasil disimpan');
      }
      onClose();
    } catch (err) {
      console.error(err);
      toast.error('Gagal menyimpan catatan hafalan');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end md:items-center justify-center bg-black/40 p-0 md:p-4 animate-fade-in">
      <div className="bg-white dark:bg-gray-800 w-full md:max-w-xl md:rounded-2xl rounded-t-2xl max-h-[92vh] overflow-y-auto animate-slide-up">
        <div className="sticky top-0 bg-white dark:bg-gray-800 flex items-center justify-between px-5 py-4 border-b border-gray-100 dark:border-gray-700">
          <h3 className="font-semibold text-gray-900 dark:text-white">{entry ? 'Edit Catatan Hafalan' : 'Input Hafalan Harian'}</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"><X size={20} /></button>
        </div>
        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          <div>
            <label className="label-field">Santri</label>
            <select className="input-field" value={form.studentId} onChange={handleStudentChange} disabled={!!entry}>
              <option value="">Pilih Santri</option>
              {students.map((s) => <option key={s.id} value={s.id}>{s.nama} ({s.nis})</option>)}
            </select>
            {errors.studentId && <p className="text-xs text-red-500 mt-1">{errors.studentId}</p>}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label-field">Tanggal</label>
              <input type="date" className="input-field" value={form.tanggal} onChange={set('tanggal')} />
            </div>
            <div>
              <label className="label-field">Surat</label>
              <input className="input-field" value={form.surat} onChange={set('surat')} placeholder="Contoh: Al-Baqarah" />
              {errors.surat && <p className="text-xs text-red-500 mt-1">{errors.surat}</p>}
            </div>
            <div>
              <label className="label-field">Ayat</label>
              <input className="input-field" value={form.ayat} onChange={set('ayat')} placeholder="1-10" />
            </div>
            <div>
              <label className="label-field">Halaman</label>
              <input className="input-field" value={form.halaman} onChange={set('halaman')} />
            </div>
            <div>
              <label className="label-field">Ziyadah (halaman baru)</label>
              <input className="input-field" value={form.ziyadah} onChange={set('ziyadah')} />
            </div>
            <div>
              <label className="label-field">Murajaah (pengulangan)</label>
              <input className="input-field" value={form.murajaah} onChange={set('murajaah')} />
            </div>
            <div>
              <label className="label-field">Nilai (0-100)</label>
              <input type="number" min="0" max="100" className="input-field" value={form.nilai} onChange={set('nilai')} />
              {errors.nilai && <p className="text-xs text-red-500 mt-1">{errors.nilai}</p>}
            </div>
            <div>
              <label className="label-field">Kelancaran</label>
              <select className="input-field" value={form.kelancaran} onChange={set('kelancaran')}>
                {KELANCARAN_OPTIONS.map((o) => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>
            <div>
              <label className="label-field">Makharijul Huruf</label>
              <select className="input-field" value={form.makharij} onChange={set('makharij')}>
                {NILAI_TAJWID_OPTIONS.map((o) => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>
            <div>
              <label className="label-field">Tajwid</label>
              <select className="input-field" value={form.tajwid} onChange={set('tajwid')}>
                {NILAI_TAJWID_OPTIONS.map((o) => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>
          </div>
          <div>
            <label className="label-field">Catatan Musyrif</label>
            <textarea className="input-field" rows={2} value={form.catatan} onChange={set('catatan')} />
          </div>

          <div className="flex gap-2 pt-2">
            <button type="button" onClick={onClose} className="btn-secondary flex-1">Batal</button>
            <button type="submit" disabled={saving} className="btn-primary flex-1">{saving ? 'Menyimpan...' : 'Simpan'}</button>
          </div>
        </form>
      </div>
    </div>
  );
}
