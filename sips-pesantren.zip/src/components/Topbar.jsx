import { Moon, Sun, Bell, GraduationCap, HardDrive, Cloud } from 'lucide-react';
import { useTheme } from '../context/ThemeContext.jsx';
import { useDataMode } from '../context/DataModeContext.jsx';
import { useNavigate } from 'react-router-dom';

export default function Topbar({ title }) {
  const { dark, toggle } = useTheme();
  const { mode } = useDataMode();
  const navigate = useNavigate();

  return (
    <header className="sticky top-0 z-30 flex items-center justify-between h-16 px-4 md:px-6 bg-white/95 dark:bg-gray-800/95 backdrop-blur border-b border-gray-100 dark:border-gray-700">
      <div className="flex items-center gap-2 md:hidden">
        <div className="w-8 h-8 rounded-lg bg-brand-600 flex items-center justify-center">
          <GraduationCap className="text-white" size={16} />
        </div>
        <span className="font-bold text-gray-900 dark:text-white">SIPS</span>
        <span className={`inline-flex items-center gap-1 text-[10px] font-medium px-2 py-0.5 rounded-full ${
          mode === 'local' ? 'bg-amber-50 text-amber-600 dark:bg-amber-900/20' : 'bg-brand-50 text-brand-600 dark:bg-brand-900/20'
        }`}>
          {mode === 'local' ? <HardDrive size={10} /> : <Cloud size={10} />}
          {mode === 'local' ? 'Lokal' : 'Cloud'}
        </span>
      </div>
      <h1 className="hidden md:block text-lg font-semibold text-gray-900 dark:text-white">{title}</h1>

      <div className="flex items-center gap-1.5">
        <button
          onClick={() => navigate('/notifikasi')}
          className="w-9 h-9 flex items-center justify-center rounded-xl text-gray-500 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-700 relative"
          aria-label="Notifikasi"
        >
          <Bell size={18} />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-rose-500 rounded-full" />
        </button>
        <button
          onClick={toggle}
          className="w-9 h-9 flex items-center justify-center rounded-xl text-gray-500 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-700"
          aria-label="Ganti tema"
        >
          {dark ? <Sun size={18} /> : <Moon size={18} />}
        </button>
      </div>
    </header>
  );
}
