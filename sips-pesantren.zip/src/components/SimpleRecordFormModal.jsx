import { useEffect, useState } from 'react';
import { X, Upload } from 'lucide-react';
import toast from 'react-hot-toast';
import { uploadEvidencePhoto } from '../services/recordService';

/**
 * Modal form generik yang dikonfigurasi lewat props `fields`.
 * fields: [{ key, label, type: 'text'|'number'|'date'|'select'|'textarea'|'photo', options?, required? }]
 */
export default function SimpleRecordFormModal({ open, onClose, title, fields, students, service, entry, photoFolder, onAfterSave }) {
  const emptyForm = fields.reduce((acc, f) => ({ ...acc, [f.key]: f.default ?? '' }), { studentId: '', studentName: '' });
  const [form, setForm] = useState(emptyForm);
  const [photoFile, setPhotoFile] = useState(null);
  const [preview, setPreview] = useState('');
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (entry) {
      const dateKey = fields.find((f) => f.type === 'date')?.key;
      setForm({
        ...emptyForm,
        ...entry,
        [dateKey]: entry[dateKey]?.toDate ? entry[dateKey].toDate().toISOString().slice(0, 10) : entry[dateKey]
      });
      setPreview(entry.foto || '');
    } else {
      setForm(emptyForm);
      setPreview('');
    }
    setPhotoFile(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [entry, open]);

  if (!open) return null;
  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));

  const handleStudentChange = (e) => {
    const id = e.target.value;
    const s = students.find((x) => x.id === id);
    setForm((f) => ({ ...f, studentId: id, studentName: s?.nama || '' }));
  };

  const handlePhoto = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setPhotoFile(file);
    setPreview(URL.createObjectURL(file));
  };

  const validate = () => {
    const e = {};
    if (!form.studentId) e.studentId = 'Pilih santri terlebih dahulu';
    fields.forEach((f) => {
      if (f.required && !String(form[f.key] || '').trim()) e[f.key] = `${f.label} wajib diisi`;
    });
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async (ev) => {
    ev.preventDefault();
    if (!validate()) return;
    setSaving(true);
    try {
      let foto = form.foto || '';
      if (photoFile) foto = await uploadEvidencePhoto(photoFile, photoFolder, form.studentId);
      const payload = { ...form, foto };
      const isNew = !entry?.id;
      if (!isNew) {
        await service.update(entry.id, payload);
        toast.success('Data berhasil diperbarui');
      } else {
        await service.create(payload);
        toast.success('Data berhasil disimpan');
        if (onAfterSave) await onAfterSave(payload);
      }
      onClose();
    } catch (err) {
      console.error(err);
      toast.error('Gagal menyimpan data');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end md:items-center justify-center bg-black/40 p-0 md:p-4 animate-fade-in">
      <div className="bg-white dark:bg-gray-800 w-full md:max-w-lg md:rounded-2xl rounded-t-2xl max-h-[92vh] overflow-y-auto animate-slide-up">
        <div className="sticky top-0 bg-white dark:bg-gray-800 flex items-center justify-between px-5 py-4 border-b border-gray-100 dark:border-gray-700">
          <h3 className="font-semibold text-gray-900 dark:text-white">{title}</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"><X size={20} /></button>
        </div>
        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          <div>
            <label className="label-field">Santri</label>
            <select className="input-field" value={form.studentId} onChange={handleStudentChange} disabled={!!entry}>
              <option value="">Pilih Santri</option>
              {students.map((s) => <option key={s.id} value={s.id}>{s.nama} ({s.nis})</option>)}
            </select>
            {errors.studentId && <p className="text-xs text-red-500 mt-1">{errors.studentId}</p>}
          </div>

          {fields.map((f) => (
            <div key={f.key}>
              {f.type === 'photo' ? (
                <>
                  <label className="label-field">{f.label}</label>
                  <div className="flex items-center gap-3">
                    {preview && <img src={preview} alt="preview" className="w-14 h-14 rounded-xl object-cover bg-gray-100" />}
                    <label className="btn-secondary cursor-pointer text-sm flex items-center gap-2">
                      <Upload size={15} /> Unggah
                      <input type="file" accept="image/*" onChange={handlePhoto} className="hidden" />
                    </label>
                  </div>
                </>
              ) : f.type === 'select' ? (
                <>
                  <label className="label-field">{f.label}</label>
                  <select className="input-field" value={form[f.key]} onChange={set(f.key)}>
                    <option value="">Pilih {f.label}</option>
                    {f.options.map((o) => <option key={o} value={o}>{o}</option>)}
                  </select>
                </>
              ) : f.type === 'textarea' ? (
                <>
                  <label className="label-field">{f.label}</label>
                  <textarea className="input-field" rows={2} value={form[f.key]} onChange={set(f.key)} />
                </>
              ) : (
                <>
                  <label className="label-field">{f.label}</label>
                  <input type={f.type} className="input-field" value={form[f.key]} onChange={set(f.key)} />
                </>
              )}
              {errors[f.key] && <p className="text-xs text-red-500 mt-1">{errors[f.key]}</p>}
            </div>
          ))}

          <div className="flex gap-2 pt-2">
            <button type="button" onClick={onClose} className="btn-secondary flex-1">Batal</button>
            <button type="submit" disabled={saving} className="btn-primary flex-1">{saving ? 'Menyimpan...' : 'Simpan'}</button>
          </div>
        </form>
      </div>
    </div>
  );
}
