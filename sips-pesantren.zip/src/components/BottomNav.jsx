import { NavLink } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { NAV_ITEMS, BOTTOM_NAV_BY_ROLE } from '../utils/navConfig.js';

export default function BottomNav() {
  const { role } = useAuth();
  const paths = BOTTOM_NAV_BY_ROLE[role] || ['/'];
  const items = paths
    .map((p) => NAV_ITEMS.find((n) => n.to === p))
    .filter(Boolean);

  return (
    <nav className="md:hidden fixed bottom-0 inset-x-0 z-40 bg-white/95 dark:bg-gray-800/95 backdrop-blur border-t border-gray-100 dark:border-gray-700 pb-[env(safe-area-inset-bottom)]">
      <div className="flex justify-around items-center h-16">
        {items.map(({ to, label, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            end={to === '/'}
            className={({ isActive }) =>
              `flex flex-col items-center justify-center gap-0.5 w-full h-full text-[11px] font-medium transition-colors ${
                isActive ? 'text-brand-600 dark:text-brand-400' : 'text-gray-400 dark:text-gray-500'
              }`
            }
          >
            <Icon size={20} />
            {label}
          </NavLink>
        ))}
      </div>
    </nav>
  );
}
