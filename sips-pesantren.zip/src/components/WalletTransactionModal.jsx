import { useState } from 'react';
import { X } from 'lucide-react';
import toast from 'react-hot-toast';
import { processWalletTransaction, transferBetweenWallets } from '../services/walletService';
import { useAuth } from '../context/AuthContext.jsx';

const TYPE_LABEL = { masuk: 'Top Up Saldo', keluar: 'Penarikan', jajan: 'Catat Jajan', transfer: 'Transfer ke Santri Lain' };

export default function WalletTransactionModal({ open, onClose, student, students, type }) {
  const { profile } = useAuth();
  const [nominal, setNominal] = useState('');
  const [catatan, setCatatan] = useState('');
  const [targetId, setTargetId] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  if (!open || !student) return null;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    const nominalNum = Number(nominal);
    if (!nominalNum || nominalNum <= 0) {
      setError('Nominal harus lebih dari 0');
      return;
    }
    if (type === 'transfer' && !targetId) {
      setError('Pilih santri tujuan transfer');
      return;
    }
    setSaving(true);
    try {
      if (type === 'transfer') {
        const target = students.find((s) => s.id === targetId);
        await transferBetweenWallets({
          fromStudentId: student.id, fromName: student.nama,
          toStudentId: target.id, toName: target.nama,
          nominal: nominalNum, createdBy: profile?.name
        });
      } else {
        await processWalletTransaction({
          studentId: student.id, studentName: student.nama,
          jenis: type, nominal: nominalNum, catatan, createdBy: profile?.name
        });
      }
      toast.success('Transaksi berhasil disimpan');
      onClose();
    } catch (err) {
      toast.error(err.message === 'Saldo tidak mencukupi' ? 'Saldo tidak mencukupi' : 'Transaksi gagal diproses');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end md:items-center justify-center bg-black/40 p-0 md:p-4 animate-fade-in">
      <div className="bg-white dark:bg-gray-800 w-full md:max-w-sm md:rounded-2xl rounded-t-2xl animate-slide-up">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100 dark:border-gray-700">
          <h3 className="font-semibold text-gray-900 dark:text-white">{TYPE_LABEL[type]}</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"><X size={20} /></button>
        </div>
        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          <p className="text-sm text-gray-500 dark:text-gray-400">Santri: <span className="font-medium text-gray-900 dark:text-white">{student.nama}</span></p>

          {type === 'transfer' && (
            <div>
              <label className="label-field">Transfer ke</label>
              <select className="input-field" value={targetId} onChange={(e) => setTargetId(e.target.value)}>
                <option value="">Pilih santri tujuan</option>
                {students.filter((s) => s.id !== student.id).map((s) => (
                  <option key={s.id} value={s.id}>{s.nama} ({s.nis})</option>
                ))}
              </select>
            </div>
          )}

          <div>
            <label className="label-field">Nominal (Rp)</label>
            <input type="number" min="0" className="input-field" value={nominal} onChange={(e) => setNominal(e.target.value)} placeholder="0" />
          </div>
          <div>
            <label className="label-field">Catatan (opsional)</label>
            <input className="input-field" value={catatan} onChange={(e) => setCatatan(e.target.value)} />
          </div>
          {error && <p className="text-xs text-red-500">{error}</p>}

          <div className="flex gap-2 pt-1">
            <button type="button" onClick={onClose} className="btn-secondary flex-1">Batal</button>
            <button type="submit" disabled={saving} className="btn-primary flex-1">{saving ? 'Memproses...' : 'Konfirmasi'}</button>
          </div>
        </form>
      </div>
    </div>
  );
}
