import { useEffect, useState } from 'react';
import { X, Upload } from 'lucide-react';
import toast from 'react-hot-toast';
import { createStudent, updateStudent, uploadStudentPhoto } from '../services/studentService';

const emptyForm = {
  nis: '', nama: '', tempatLahir: '', tanggalLahir: '', jenisKelamin: 'L',
  alamat: '', namaAyah: '', namaIbu: '', noHpWali: '', kelas: '', kamar: '',
  status: 'aktif', tanggalMasuk: ''
};

export default function StudentFormModal({ open, onClose, student }) {
  const [form, setForm] = useState(emptyForm);
  const [photoFile, setPhotoFile] = useState(null);
  const [preview, setPreview] = useState('');
  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (student) {
      setForm({ ...emptyForm, ...student });
      setPreview(student.foto || '');
    } else {
      setForm(emptyForm);
      setPreview('');
    }
    setPhotoFile(null);
  }, [student, open]);

  if (!open) return null;

  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));

  const handlePhoto = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setPhotoFile(file);
    setPreview(URL.createObjectURL(file));
  };

  const validate = () => {
    const e = {};
    if (!form.nis.trim()) e.nis = 'NIS wajib diisi';
    if (!form.nama.trim()) e.nama = 'Nama wajib diisi';
    if (!form.kelas.trim()) e.kelas = 'Kelas wajib diisi';
    if (form.noHpWali && !/^[0-9+\s-]{8,15}$/.test(form.noHpWali)) e.noHpWali = 'Nomor HP tidak valid';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async (ev) => {
    ev.preventDefault();
    if (!validate()) return;
    setSaving(true);
    try {
      let fotoUrl = form.foto || '';
      if (photoFile) {
        fotoUrl = await uploadStudentPhoto(photoFile, form.nis);
      }
      const payload = { ...form, foto: fotoUrl };
      if (student?.id) {
        await updateStudent(student.id, payload);
        toast.success('Data santri berhasil diperbarui');
      } else {
        await createStudent(payload);
        toast.success('Santri baru berhasil ditambahkan');
      }
      onClose();
    } catch (err) {
      console.error(err);
      toast.error('Gagal menyimpan data santri');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end md:items-center justify-center bg-black/40 p-0 md:p-4 animate-fade-in">
      <div className="bg-white dark:bg-gray-800 w-full md:max-w-2xl md:rounded-2xl rounded-t-2xl max-h-[92vh] overflow-y-auto animate-slide-up">
        <div className="sticky top-0 bg-white dark:bg-gray-800 flex items-center justify-between px-5 py-4 border-b border-gray-100 dark:border-gray-700">
          <h3 className="font-semibold text-gray-900 dark:text-white">{student ? 'Edit Data Santri' : 'Tambah Santri Baru'}</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200">
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          <div className="flex items-center gap-4">
            <img
              src={preview || `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(form.nama || 'S')}`}
              alt="Foto santri"
              className="w-16 h-16 rounded-2xl object-cover bg-gray-100"
            />
            <label className="btn-secondary cursor-pointer text-sm flex items-center gap-2">
              <Upload size={15} /> Unggah Foto
              <input type="file" accept="image/*" onChange={handlePhoto} className="hidden" />
            </label>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label-field">NIS</label>
              <input className="input-field" value={form.nis} onChange={set('nis')} disabled={!!student} />
              {errors.nis && <p className="text-xs text-red-500 mt-1">{errors.nis}</p>}
            </div>
            <div>
              <label className="label-field">Nama Lengkap</label>
              <input className="input-field" value={form.nama} onChange={set('nama')} />
              {errors.nama && <p className="text-xs text-red-500 mt-1">{errors.nama}</p>}
            </div>
            <div>
              <label className="label-field">Tempat Lahir</label>
              <input className="input-field" value={form.tempatLahir} onChange={set('tempatLahir')} />
            </div>
            <div>
              <label className="label-field">Tanggal Lahir</label>
              <input type="date" className="input-field" value={form.tanggalLahir} onChange={set('tanggalLahir')} />
            </div>
            <div>
              <label className="label-field">Jenis Kelamin</label>
              <select className="input-field" value={form.jenisKelamin} onChange={set('jenisKelamin')}>
                <option value="L">Laki-laki</option>
                <option value="P">Perempuan</option>
              </select>
            </div>
            <div>
              <label className="label-field">Status</label>
              <select className="input-field" value={form.status} onChange={set('status')}>
                <option value="aktif">Aktif</option>
                <option value="cuti">Cuti</option>
                <option value="lulus">Lulus</option>
                <option value="keluar">Keluar</option>
              </select>
            </div>
            <div className="col-span-2">
              <label className="label-field">Alamat</label>
              <textarea className="input-field" rows={2} value={form.alamat} onChange={set('alamat')} />
            </div>
            <div>
              <label className="label-field">Nama Ayah</label>
              <input className="input-field" value={form.namaAyah} onChange={set('namaAyah')} />
            </div>
            <div>
              <label className="label-field">Nama Ibu</label>
              <input className="input-field" value={form.namaIbu} onChange={set('namaIbu')} />
            </div>
            <div>
              <label className="label-field">No. HP Wali</label>
              <input className="input-field" value={form.noHpWali} onChange={set('noHpWali')} placeholder="08xxxxxxxxxx" />
              {errors.noHpWali && <p className="text-xs text-red-500 mt-1">{errors.noHpWali}</p>}
            </div>
            <div>
              <label className="label-field">Kelas</label>
              <input className="input-field" value={form.kelas} onChange={set('kelas')} placeholder="Contoh: 8A" />
              {errors.kelas && <p className="text-xs text-red-500 mt-1">{errors.kelas}</p>}
            </div>
            <div>
              <label className="label-field">Kamar</label>
              <input className="input-field" value={form.kamar} onChange={set('kamar')} placeholder="Contoh: Kamar 3" />
            </div>
            <div>
              <label className="label-field">Tanggal Masuk</label>
              <input type="date" className="input-field" value={form.tanggalMasuk} onChange={set('tanggalMasuk')} />
            </div>
          </div>

          <div className="flex gap-2 pt-2">
            <button type="button" onClick={onClose} className="btn-secondary flex-1">Batal</button>
            <button type="submit" disabled={saving} className="btn-primary flex-1">
              {saving ? 'Menyimpan...' : 'Simpan Data'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
