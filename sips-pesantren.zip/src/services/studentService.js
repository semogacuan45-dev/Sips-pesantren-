import * as XLSX from 'xlsx';
import { addRecord, updateRecord, deleteRecord, getAllOnce } from '../data/store';
import { uploadPhoto } from '../data/photoStore';

const COL = 'students';

export async function createStudent(payload) {
  return addRecord(COL, {
    ...payload,
    totalHafalanJuz: payload.totalHafalanJuz || 0,
    status: payload.status || 'aktif'
  });
}

export async function updateStudent(id, payload) {
  return updateRecord(COL, id, payload);
}

export async function deleteStudent(id) {
  return deleteRecord(COL, id);
}

export async function uploadStudentPhoto(file, nis) {
  return uploadPhoto(file, 'students', nis);
}

/** Export daftar santri ke file Excel (.xlsx) */
export function exportStudentsToExcel(students, filename = 'data-santri.xlsx') {
  const rows = students.map((s) => ({
    NIS: s.nis,
    Nama: s.nama,
    'Tempat Lahir': s.tempatLahir,
    'Tanggal Lahir': s.tanggalLahir,
    'Jenis Kelamin': s.jenisKelamin,
    Alamat: s.alamat,
    'Nama Ayah': s.namaAyah,
    'Nama Ibu': s.namaIbu,
    'No HP Wali': s.noHpWali,
    Kelas: s.kelas,
    Kamar: s.kamar,
    Status: s.status,
    'Tanggal Masuk': s.tanggalMasuk
  }));
  const ws = XLSX.utils.json_to_sheet(rows);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Data Santri');
  XLSX.writeFile(wb, filename);
}

/** Import santri dari file Excel (.xlsx/.xls). Mengembalikan ringkasan hasil impor. */
export async function importStudentsFromExcel(file) {
  const buffer = await file.arrayBuffer();
  const wb = XLSX.read(buffer, { type: 'array' });
  const sheet = wb.Sheets[wb.SheetNames[0]];
  const rows = XLSX.utils.sheet_to_json(sheet);

  const mapped = rows.map((r) => ({
    nis: String(r.NIS || r.nis || ''),
    nama: r.Nama || r.nama || '',
    tempatLahir: r['Tempat Lahir'] || r.tempatLahir || '',
    tanggalLahir: r['Tanggal Lahir'] || r.tanggalLahir || '',
    jenisKelamin: r['Jenis Kelamin'] || r.jenisKelamin || 'L',
    alamat: r.Alamat || r.alamat || '',
    namaAyah: r['Nama Ayah'] || r.namaAyah || '',
    namaIbu: r['Nama Ibu'] || r.namaIbu || '',
    noHpWali: String(r['No HP Wali'] || r.noHpWali || ''),
    kelas: r.Kelas || r.kelas || '',
    kamar: r.Kamar || r.kamar || '',
    status: r.Status || 'aktif',
    tanggalMasuk: r['Tanggal Masuk'] || r.tanggalMasuk || ''
  }));

  const results = { success: 0, failed: 0 };
  for (const item of mapped) {
    if (!item.nis || !item.nama) {
      results.failed += 1;
      continue;
    }
    try {
      await createStudent(item);
      results.success += 1;
    } catch (e) {
      console.error('Gagal impor baris:', item, e);
      results.failed += 1;
    }
  }
  return results;
}

export async function getAllStudentsOnce() {
  return getAllOnce(COL);
}
