import { addRecord, updateRecord, deleteRecord, toStorableDate } from '../data/store';
import { uploadPhoto } from '../data/photoStore';

export function createRecordService(collectionName) {
  return {
    async create(payload) {
      const data = { ...payload };
      if (payload.tanggal) data.tanggal = toStorableDate(payload.tanggal);
      return addRecord(collectionName, data);
    },
    async update(id, payload) {
      const data = { ...payload };
      if (payload.tanggal) data.tanggal = toStorableDate(payload.tanggal);
      return updateRecord(collectionName, id, data);
    },
    async remove(id) {
      return deleteRecord(collectionName, id);
    }
  };
}

export async function uploadEvidencePhoto(file, folder, id) {
  return uploadPhoto(file, folder, id);
}
