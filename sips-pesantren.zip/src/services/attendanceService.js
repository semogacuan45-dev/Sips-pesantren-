import { getAllOnce, addRecord, updateRecord, toStorableDate } from '../data/store';

const COL = 'attendance';

export const STATUS_OPTIONS = ['hadir', 'izin', 'sakit', 'alpa', 'terlambat'];

function toJsDate(value) {
  if (!value) return null;
  return value?.toDate ? value.toDate() : new Date(value);
}

/** Mengambil semua data absensi pada tanggal tertentu (yyyy-mm-dd), bekerja di kedua mode. */
export async function getAttendanceForDate(dateStr) {
  const all = await getAllOnce(COL);
  const target = dateStr;
  return all.filter((r) => {
    const d = toJsDate(r.tanggal);
    if (!d) return false;
    return d.toISOString().slice(0, 10) === target;
  });
}

export async function setAttendance({ id, studentId, studentName, tanggal, status, catatan }) {
  const payload = {
    studentId,
    studentName,
    tanggal: toStorableDate(tanggal),
    status,
    catatan: catatan || ''
  };
  if (id) {
    return updateRecord(COL, id, payload);
  }
  return addRecord(COL, payload);
}
