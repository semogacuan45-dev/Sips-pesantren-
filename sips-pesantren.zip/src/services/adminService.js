import { createUserWithEmailAndPassword, sendPasswordResetEmail } from 'firebase/auth';
import { auth } from '../firebase/config';
import { addRecord, updateRecord, deleteRecord, getAllOnce, isLocal } from '../data/store';
import { getAll as localGetAll, updateDoc as localUpdateDoc } from '../data/localStore';

const BACKUP_COLLECTIONS = [
  'users', 'students', 'classes', 'rooms', 'attendance', 'tahfidz', 'tahsin',
  'violations', 'achievements', 'wallets', 'transactions', 'notifications', 'settings'
];

/** Membuat akun pengguna baru (guru/musyrif/bendahara/wali). */
export async function createUserAccount({ email, password, name, role, studentId }) {
  if (isLocal()) {
    const existing = localGetAll('users').find((u) => u.email.toLowerCase() === email.toLowerCase());
    if (existing) {
      const err = new Error('Email sudah terdaftar');
      err.code = 'auth/email-already-in-use';
      throw err;
    }
    if (password.length < 6) {
      const err = new Error('Kata sandi terlalu lemah');
      err.code = 'auth/weak-password';
      throw err;
    }
    return addRecord('users', { email, password, name, role, studentId: studentId || null });
  }

  const cred = await createUserWithEmailAndPassword(auth, email, password);
  await addRecord('users', {
    uid: cred.user.uid,
    email,
    name,
    role,
    studentId: studentId || null
  });
  return cred.user;
}

/** Mode Cloud: kirim email reset. Mode Lokal: reset ke kata sandi sementara. */
export async function resetUserPassword(email) {
  if (isLocal()) {
    const found = localGetAll('users').find((u) => u.email.toLowerCase() === email.toLowerCase());
    if (!found) {
      const err = new Error('Email tidak ditemukan');
      err.code = 'auth/user-not-found';
      throw err;
    }
    const tempPassword = 'sips12345';
    localUpdateDoc('users', found.id, { password: tempPassword });
    return { localReset: true, tempPassword };
  }
  return sendPasswordResetEmail(auth, email);
}

export const classService = {
  create: (payload) => addRecord('classes', payload),
  update: (id, payload) => updateRecord('classes', id, payload),
  remove: (id) => deleteRecord('classes', id)
};

export const roomService = {
  create: (payload) => addRecord('rooms', payload),
  update: (id, payload) => updateRecord('rooms', id, payload),
  remove: (id) => deleteRecord('rooms', id)
};

/** Mengekspor seluruh koleksi penting (dari mode yang sedang aktif) menjadi satu file JSON backup. */
export async function backupAllData() {
  const backup = {};
  for (const col of BACKUP_COLLECTIONS) {
    backup[col] = await getAllOnce(col);
  }
  const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `sips-backup-${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
  return backup;
}

/**
 * Restore data dari file backup JSON ke mode yang sedang aktif. CATATAN: proses ini
 * menambahkan dokumen baru (tidak menimpa ID lama) untuk mencegah kehilangan data.
 */
export async function restoreFromBackupFile(file) {
  const text = await file.text();
  const backup = JSON.parse(text);
  const results = {};
  for (const col of Object.keys(backup)) {
    if (!BACKUP_COLLECTIONS.includes(col)) continue;
    let count = 0;
    for (const item of backup[col]) {
      const { id, ...rest } = item;
      await addRecord(col, rest);
      count += 1;
    }
    results[col] = count;
  }
  return results;
}
