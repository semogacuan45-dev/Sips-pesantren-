import { doc, runTransaction } from 'firebase/firestore';
import { db } from '../firebase/config';
import { getOne, addRecord, setRecord, isLocal } from '../data/store';
import { getDoc as localGetDoc, setDoc as localSetDoc } from '../data/localStore';

const WALLETS = 'wallets';
const TX = 'transactions';

export async function getOrCreateWallet(studentId, studentName) {
  const existing = await getOne(WALLETS, studentId);
  if (existing) return existing;
  const initial = { studentId, studentName, saldo: 0, pin: null };
  await setRecord(WALLETS, studentId, initial);
  return { id: studentId, ...initial };
}

/**
 * Melakukan transaksi dompet (top up / penarikan / jajan / refund) secara konsisten.
 * Mode Cloud memakai Firestore transaction (aman untuk banyak pengguna sekaligus).
 * Mode Lokal memakai read-modify-write biasa (aman karena hanya 1 pengguna per browser).
 */
export async function processWalletTransaction({ studentId, studentName, jenis, nominal, catatan, createdBy }) {
  const nominalAbs = Math.abs(Number(nominal));
  const isDebit = jenis === 'keluar' || jenis === 'jajan';

  if (isLocal()) {
    const wallet = localGetDoc(WALLETS, studentId) || { id: studentId, studentId, studentName, saldo: 0 };
    if (isDebit && (wallet.saldo || 0) < nominalAbs) {
      throw new Error('Saldo tidak mencukupi');
    }
    const newSaldo = isDebit ? (wallet.saldo || 0) - nominalAbs : (wallet.saldo || 0) + nominalAbs;
    localSetDoc(WALLETS, studentId, { studentId, studentName, saldo: newSaldo });
  } else {
    const walletRef = doc(db, WALLETS, studentId);
    await runTransaction(db, async (transaction) => {
      const walletSnap = await transaction.get(walletRef);
      const currentSaldo = walletSnap.exists() ? walletSnap.data().saldo || 0 : 0;
      if (isDebit && currentSaldo < nominalAbs) {
        throw new Error('Saldo tidak mencukupi');
      }
      const newSaldo = isDebit ? currentSaldo - nominalAbs : currentSaldo + nominalAbs;
      if (walletSnap.exists()) {
        transaction.update(walletRef, { saldo: newSaldo });
      } else {
        transaction.set(walletRef, { studentId, studentName, saldo: newSaldo, pin: null });
      }
    });
  }

  return addRecord(TX, {
    studentId,
    studentName,
    jenis, // masuk | keluar | transfer | refund | jajan
    nominal: nominalAbs,
    catatan: catatan || '',
    createdBy: createdBy || ''
  });
}

export async function transferBetweenWallets({ fromStudentId, fromName, toStudentId, toName, nominal, createdBy }) {
  await processWalletTransaction({ studentId: fromStudentId, studentName: fromName, jenis: 'keluar', nominal, catatan: `Transfer ke ${toName}`, createdBy });
  await processWalletTransaction({ studentId: toStudentId, studentName: toName, jenis: 'masuk', nominal, catatan: `Transfer dari ${fromName}`, createdBy });
}

export async function setWalletPin(studentId, pin) {
  return setRecord(WALLETS, studentId, { pin });
}
