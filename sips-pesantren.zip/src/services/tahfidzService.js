import { addRecord, updateRecord, deleteRecord, toStorableDate } from '../data/store';

const COL = 'tahfidz';

export async function createTahfidzEntry(payload) {
  return addRecord(COL, {
    ...payload,
    tanggal: payload.tanggal ? toStorableDate(payload.tanggal) : toStorableDate(new Date().toISOString().slice(0, 10))
  });
}

export async function updateTahfidzEntry(id, payload) {
  const data = { ...payload };
  if (payload.tanggal) data.tanggal = toStorableDate(payload.tanggal);
  return updateRecord(COL, id, data);
}

export async function deleteTahfidzEntry(id) {
  return deleteRecord(COL, id);
}

export const KELANCARAN_OPTIONS = ['Lancar', 'Cukup Lancar', 'Kurang Lancar', 'Tidak Lancar'];
export const NILAI_TAJWID_OPTIONS = ['Sangat Baik', 'Baik', 'Cukup', 'Perlu Perbaikan'];
