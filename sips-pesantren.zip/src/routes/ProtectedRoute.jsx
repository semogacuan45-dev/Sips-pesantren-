import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import FullScreenLoader from '../components/FullScreenLoader.jsx';

export default function ProtectedRoute({ children, allowedRoles }) {
  const { user, role, loading } = useAuth();

  if (loading) return <FullScreenLoader />;
  if (!user) return <Navigate to="/login" replace />;
  if (allowedRoles && !allowedRoles.includes(role)) {
    return <Navigate to="/" replace />;
  }
  return children;
}
