// Mesin penyimpanan lokal: menyimpan seluruh "koleksi" di satu key localStorage,
// dengan pub/sub sederhana agar komponen React tetap reaktif seperti onSnapshot Firestore.
// Cocok untuk mode demo/offline tanpa Firebase - data hanya tersimpan di browser ini.

const DB_KEY = 'sips_local_db';
const listenersMap = new Map(); // collectionName -> Set(callback)

const DEFAULT_DB = {
  users: [], students: [], classes: [], rooms: [], attendance: [], tahfidz: [],
  tahsin: [], violations: [], achievements: [], wallets: [], transactions: [],
  notifications: [], settings: []
};

function readDb() {
  try {
    const raw = localStorage.getItem(DB_KEY);
    return raw ? { ...DEFAULT_DB, ...JSON.parse(raw) } : { ...DEFAULT_DB };
  } catch (e) {
    console.error('Gagal membaca database lokal:', e);
    return { ...DEFAULT_DB };
  }
}

function writeDb(db) {
  try {
    localStorage.setItem(DB_KEY, JSON.stringify(db));
  } catch (e) {
    console.error('Gagal menyimpan ke penyimpanan lokal (mungkin penuh):', e);
    throw new Error('Penyimpanan lokal penuh. Hapus beberapa foto/data lama atau pindah ke mode Cloud.');
  }
}

function notify(collectionName) {
  const set = listenersMap.get(collectionName);
  if (set) set.forEach((cb) => cb(getAll(collectionName)));
}

function genId() {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) return crypto.randomUUID();
  return `id-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}

export function getAll(collectionName) {
  const db = readDb();
  return db[collectionName] || [];
}

export function getDoc(collectionName, id) {
  return getAll(collectionName).find((r) => r.id === id) || null;
}

/** Berlangganan perubahan sebuah koleksi. Memanggil callback segera dan setiap ada perubahan. */
export function subscribe(collectionName, callback) {
  if (!listenersMap.has(collectionName)) listenersMap.set(collectionName, new Set());
  listenersMap.get(collectionName).add(callback);
  callback(getAll(collectionName));
  return () => listenersMap.get(collectionName)?.delete(callback);
}

export function addDoc(collectionName, data) {
  const db = readDb();
  const id = genId();
  const record = { ...data, id, createdAt: new Date().toISOString() };
  db[collectionName] = [...(db[collectionName] || []), record];
  writeDb(db);
  notify(collectionName);
  return record;
}

/** Membuat/menimpa dokumen dengan ID tertentu (setara Firestore setDoc). */
export function setDoc(collectionName, id, data) {
  const db = readDb();
  const list = db[collectionName] || [];
  const idx = list.findIndex((r) => r.id === id);
  if (idx >= 0) list[idx] = { ...list[idx], ...data };
  else list.push({ ...data, id });
  db[collectionName] = list;
  writeDb(db);
  notify(collectionName);
  return getDoc(collectionName, id);
}

export function updateDoc(collectionName, id, data) {
  const db = readDb();
  const list = db[collectionName] || [];
  const idx = list.findIndex((r) => r.id === id);
  if (idx < 0) return;
  list[idx] = { ...list[idx], ...data, updatedAt: new Date().toISOString() };
  db[collectionName] = list;
  writeDb(db);
  notify(collectionName);
}

export function deleteDoc(collectionName, id) {
  const db = readDb();
  db[collectionName] = (db[collectionName] || []).filter((r) => r.id !== id);
  writeDb(db);
  notify(collectionName);
}

export function exportAll() {
  return readDb();
}

export function importAll(data) {
  const db = readDb();
  Object.keys(data).forEach((col) => {
    if (!(col in DEFAULT_DB)) return;
    const incoming = (data[col] || []).map((it) => ({ ...it, id: it.id || genId() }));
    db[col] = [...(db[col] || []), ...incoming];
  });
  writeDb(db);
  Object.keys(DEFAULT_DB).forEach(notify);
}

export function clearAll() {
  writeDb({ ...DEFAULT_DB });
  Object.keys(DEFAULT_DB).forEach(notify);
}

export function estimateSizeKB() {
  const raw = localStorage.getItem(DB_KEY) || '';
  return Math.round((raw.length * 2) / 1024); // perkiraan kasar (UTF-16)
}

/** Mengisi akun demo + 1 contoh santri, hanya jika database lokal masih kosong. */
export function seedDemoData() {
  const db = readDb();
  if (db.users.length > 0) return false;

  const studentId = genId();
  db.users = [
    { id: genId(), email: 'admin@demo.sips', password: 'admin123', name: 'Admin Demo', role: 'admin', studentId: null },
    { id: genId(), email: 'bendahara@demo.sips', password: 'bendahara123', name: 'Bendahara Demo', role: 'bendahara', studentId: null },
    { id: genId(), email: 'musyrif@demo.sips', password: 'musyrif123', name: 'Musyrif Demo', role: 'musyrif', studentId: null },
    { id: genId(), email: 'wali@demo.sips', password: 'wali123', name: 'Wali Demo', role: 'wali', studentId }
  ];
  db.students = [{
    id: studentId, nis: '2024001', nama: 'Ahmad Fauzan', tempatLahir: 'Bandung',
    tanggalLahir: '2012-05-14', jenisKelamin: 'L', alamat: 'Jl. Contoh No. 1',
    namaAyah: 'Bapak Fauzan', namaIbu: 'Ibu Fauzan', noHpWali: '081234567890',
    kelas: '7A', kamar: 'Kamar 1', status: 'aktif', tanggalMasuk: '2024-07-01', totalHafalanJuz: 2
  }];
  db.wallets = [{ id: studentId, studentId, studentName: 'Ahmad Fauzan', saldo: 50000 }];
  writeDb(db);
  return true;
}
