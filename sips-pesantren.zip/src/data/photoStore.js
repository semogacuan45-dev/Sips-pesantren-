import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { storage } from '../firebase/config';
import { isLocal } from './store';

/** Mengompres & mengubah gambar menjadi data URL base64 (untuk mode Lokal). */
function resizeToDataUrl(file, maxSize = 480, quality = 0.72) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        let { width, height } = img;
        if (width > height && width > maxSize) {
          height = Math.round(height * (maxSize / width));
          width = maxSize;
        } else if (height > maxSize) {
          width = Math.round(width * (maxSize / height));
          height = maxSize;
        }
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        canvas.getContext('2d').drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL('image/jpeg', quality));
      };
      img.onerror = () => reject(new Error('Gagal memuat gambar'));
      img.src = e.target.result;
    };
    reader.onerror = () => reject(new Error('Gagal membaca file'));
    reader.readAsDataURL(file);
  });
}

/**
 * Mengunggah foto. Mode Lokal: dikompres jadi base64 dan disimpan langsung di dokumen.
 * Mode Cloud: diunggah ke Firebase Storage, mengembalikan URL publik.
 */
export async function uploadPhoto(file, folder, id) {
  if (isLocal()) {
    return resizeToDataUrl(file);
  }
  const fileRef = ref(storage, `${folder}/${id}/${Date.now()}.jpg`);
  await uploadBytes(fileRef, file);
  return getDownloadURL(fileRef);
}
