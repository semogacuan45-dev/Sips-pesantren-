// Satu-satunya pintu akses data untuk seluruh aplikasi. Semua service memanggil
// fungsi di sini, bukan langsung ke Firestore, supaya bisa berpindah mode
// Lokal <-> Cloud tanpa mengubah halaman/komponen.
import {
  collection, doc, addDoc as fsAddDoc, updateDoc as fsUpdateDoc, deleteDoc as fsDeleteDoc,
  setDoc as fsSetDoc, getDoc as fsGetDoc, getDocs, onSnapshot, query,
  orderBy as fsOrderBy, serverTimestamp, Timestamp
} from 'firebase/firestore';
import { db } from '../firebase/config';
import { getMode } from './mode';
import * as local from './localStore';

const isLocal = () => getMode() === 'local';

/** Berlangganan realtime pada sebuah koleksi. Bekerja sama di kedua mode. */
export function subscribeCollection(collectionName, callback, orderByField, direction = 'asc') {
  if (isLocal()) {
    return local.subscribe(collectionName, (items) => {
      if (!orderByField) return callback(items);
      const sorted = [...items].sort((a, b) => {
        const av = a[orderByField] ?? '';
        const bv = b[orderByField] ?? '';
        if (av === bv) return 0;
        const gt = av > bv ? 1 : -1;
        return direction === 'desc' ? -gt : gt;
      });
      callback(sorted);
    });
  }
  const ref = collection(db, collectionName);
  const q = orderByField ? query(ref, fsOrderBy(orderByField, direction)) : ref;
  return onSnapshot(
    q,
    (snap) => callback(snap.docs.map((d) => ({ id: d.id, ...d.data() }))),
    (err) => console.error(`Gagal memuat koleksi ${collectionName}:`, err)
  );
}

export async function getAllOnce(collectionName) {
  if (isLocal()) return local.getAll(collectionName);
  const snap = await getDocs(collection(db, collectionName));
  return snap.docs.map((d) => ({ id: d.id, ...d.data() }));
}

export async function getOne(collectionName, id) {
  if (isLocal()) return local.getDoc(collectionName, id);
  const snap = await fsGetDoc(doc(db, collectionName, id));
  return snap.exists() ? { id: snap.id, ...snap.data() } : null;
}

export async function addRecord(collectionName, data) {
  if (isLocal()) return local.addDoc(collectionName, data);
  const ref = await fsAddDoc(collection(db, collectionName), { ...data, createdAt: serverTimestamp() });
  return { id: ref.id, ...data };
}

export async function setRecord(collectionName, id, data) {
  if (isLocal()) return local.setDoc(collectionName, id, data);
  return fsSetDoc(doc(db, collectionName, id), data, { merge: true });
}

export async function updateRecord(collectionName, id, data) {
  if (isLocal()) return local.updateDoc(collectionName, id, data);
  return fsUpdateDoc(doc(db, collectionName, id), { ...data, updatedAt: serverTimestamp() });
}

export async function deleteRecord(collectionName, id) {
  if (isLocal()) return local.deleteDoc(collectionName, id);
  return fsDeleteDoc(doc(db, collectionName, id));
}

/** Mengubah string tanggal (yyyy-mm-dd) menjadi format tanggal yang sesuai mode aktif. */
export function toStorableDate(dateStr) {
  if (isLocal()) return new Date(dateStr).toISOString();
  return Timestamp.fromDate(new Date(dateStr));
}

export { isLocal };
