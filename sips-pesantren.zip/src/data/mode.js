const MODE_KEY = 'sips_data_mode';
const listeners = new Set();

/** Mengembalikan mode saat ini: 'local' (default) atau 'cloud'. */
export function getMode() {
  return localStorage.getItem(MODE_KEY) || 'local';
}

export function setMode(mode) {
  localStorage.setItem(MODE_KEY, mode);
  listeners.forEach((cb) => cb(mode));
}

export function onModeChange(cb) {
  listeners.add(cb);
  return () => listeners.delete(cb);
}

/** True jika environment variable Firebase sudah diisi (mode Cloud siap dipakai). */
export function isCloudConfigured() {
  try {
    return Boolean(import.meta.env.VITE_FIREBASE_API_KEY && import.meta.env.VITE_FIREBASE_PROJECT_ID);
  } catch {
    return false;
  }
}
