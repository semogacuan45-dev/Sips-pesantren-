import { useEffect, useState } from 'react';
import { subscribeCollection } from '../data/store';
import { useDataMode } from '../context/DataModeContext.jsx';

/**
 * Berlangganan realtime pada sebuah "koleksi" data, otomatis memakai
 * localStorage (mode Lokal) atau Firestore (mode Cloud) sesuai mode aktif.
 * @param {string} collectionName nama koleksi
 * @param {string} orderByField field untuk pengurutan (opsional)
 * @param {'asc'|'desc'} direction arah urutan
 */
export function useFirestoreCollection(collectionName, orderByField = null, direction = 'desc') {
  const { mode } = useDataMode();
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    setLoading(true);
    setError(null);
    let unsub = () => {};
    try {
      unsub = subscribeCollection(
        collectionName,
        (items) => {
          setData(items);
          setLoading(false);
        },
        orderByField,
        direction
      );
    } catch (err) {
      console.error(`Gagal memuat koleksi ${collectionName}:`, err);
      setError(err.message);
      setLoading(false);
    }
    return () => unsub && unsub();
    // mode disertakan agar berlangganan ulang saat pengguna berpindah mode Lokal/Cloud
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [collectionName, orderByField, direction, mode]);

  return { data, loading, error };
}
