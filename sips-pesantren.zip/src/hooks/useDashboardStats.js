import { useEffect, useState } from 'react';
import { getAllOnce } from '../data/store';
import { useDataMode } from '../context/DataModeContext.jsx';
import { startOfDay, endOfDay, subDays, format, isWithinInterval } from 'date-fns';

function toJsDate(value) {
  if (!value) return null;
  if (value?.toDate) return value.toDate();
  return new Date(value);
}

function isInRange(value, start, end) {
  const d = toJsDate(value);
  if (!d || isNaN(d)) return false;
  return isWithinInterval(d, { start, end });
}

/**
 * Ringkasan statistik dashboard: jumlah santri, hafalan hari ini, absensi hari ini,
 * saldo total, transaksi hari ini, santri terbaik, dan tren 7 hari. Bekerja di kedua
 * mode (Lokal/Cloud) karena mengambil seluruh data lalu menghitung di sisi klien.
 */
export function useDashboardStats() {
  const { mode } = useDataMode();
  const [stats, setStats] = useState({
    totalSantri: 0,
    hafalanHariIni: 0,
    hadirHariIni: 0,
    totalSaldo: 0,
    transaksiHariIni: 0,
    santriTerbaik: [],
    trenHafalan: [],
    trenAbsensi: [],
    loading: true,
    error: null
  });

  useEffect(() => {
    let active = true;
    async function load() {
      try {
        const [students, tahfidz, attendance, wallets, transactions] = await Promise.all([
          getAllOnce('students'),
          getAllOnce('tahfidz'),
          getAllOnce('attendance'),
          getAllOnce('wallets'),
          getAllOnce('transactions')
        ]);
        if (!active) return;

        const todayStart = startOfDay(new Date());
        const todayEnd = endOfDay(new Date());

        const hafalanHariIni = tahfidz.filter((t) => isInRange(t.tanggal, todayStart, todayEnd)).length;
        const hadirHariIni = attendance.filter((a) => a.status === 'hadir' && isInRange(a.tanggal, todayStart, todayEnd)).length;
        const transaksiHariIni = transactions.filter((t) => isInRange(t.createdAt, todayStart, todayEnd)).length;
        const totalSaldo = wallets.reduce((sum, w) => sum + (w.saldo || 0), 0);

        const trenHafalan = [];
        const trenAbsensi = [];
        for (let i = 6; i >= 0; i--) {
          const day = subDays(new Date(), i);
          const label = format(day, 'dd/MM');
          const dStart = startOfDay(day);
          const dEnd = endOfDay(day);
          trenHafalan.push({ tanggal: label, jumlah: tahfidz.filter((t) => isInRange(t.tanggal, dStart, dEnd)).length });
          trenAbsensi.push({ tanggal: label, jumlah: attendance.filter((a) => a.status === 'hadir' && isInRange(a.tanggal, dStart, dEnd)).length });
        }

        const santriTerbaik = [...students]
          .sort((a, b) => (b.totalHafalanJuz || 0) - (a.totalHafalanJuz || 0))
          .slice(0, 5);

        setStats({
          totalSantri: students.length,
          hafalanHariIni,
          hadirHariIni,
          totalSaldo,
          transaksiHariIni,
          santriTerbaik,
          trenHafalan,
          trenAbsensi,
          loading: false,
          error: null
        });
      } catch (err) {
        console.error('Gagal memuat statistik dashboard:', err);
        if (active) setStats((s) => ({ ...s, loading: false, error: err.message }));
      }
    }
    load();
    return () => { active = false; };
  }, [mode]);

  return stats;
}
